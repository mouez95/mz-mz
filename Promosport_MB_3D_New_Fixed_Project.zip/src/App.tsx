/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { NotificationModal } from './components/NotificationModal';
import { ToastNotification } from './components/ToastNotification';
import { WeeklyConcoursModal } from './components/WeeklyConcoursModal';
import { PWAInstallButton, OfflineIndicator } from './components/PWAInstallControls';
import { PromosportIntroStage } from './components/PromosportIntroStage';
import { FloatingGrilleAlertBadge, FloatingGrilleAlertData } from './components/FloatingGrilleAlertBadge';
import { PromosportGrille, NotificationSettings, ToastAlert, WeeklyConcours, AppSettings, IntroAlertItem } from './types/promosport';
import {
  INITIAL_GRILLES,
  INITIAL_WEEKLY_CONCOURS,
  fetchPromosportSyncState,
  fetchPromosportLiveMatchesScan,
  archiveConcoursToGrille,
  mergeGrilleArchives,
} from './services/promosportData';
import { evaluateConcoursRealTime, isConcoursCompletelyFinished } from './services/matchLiveService';
import { mergeConcoursPreservingScores } from './services/liveFootballFeed';
import { ensureDesktopPushSubscribed } from './services/webPushClient';
import {
  loadSettings,
  saveSettings,
  loadAppSettings,
  saveAppSettings,
  buildConcoursAlertSignature,
  loadLastNotifiedSignature,
  saveLastNotifiedSignature,
  loadCachedConcours,
  saveCachedConcours,
  loadNotifiedWinnersMap,
  saveNotifiedWinnersSignature,
} from './services/storageService';
import { audioService } from './services/audioService';

export default function App() {
  const [grilles, setGrilles] = useState<PromosportGrille[]>(INITIAL_GRILLES);
  const grillesRef = useRef<PromosportGrille[]>(INITIAL_GRILLES);
  grillesRef.current = grilles;

  // App Settings state (editable App Name, Package ID, Phone, Rates)
  const [appSettings, setAppSettings] = useState<AppSettings>(() => loadAppSettings());

  // Main Screen: خانة القصاصة is now the primary root interface (home ball screen deleted permanently)
  const [weeklyConcours, setWeeklyConcours] = useState<WeeklyConcours>(
    () => loadCachedConcours(INITIAL_WEEKLY_CONCOURS.number) || INITIAL_WEEKLY_CONCOURS
  );
  const [weeklyConcoursTab, setWeeklyConcoursTab] = useState<'grille' | 'tirage' | 'live' | 'settings' | 'apk'>('grille');

  const [settings, setSettings] = useState<NotificationSettings>(() => loadSettings());
  const [isNotificationsOpen, setIsNotificationsOpen] = useState<boolean>(false);
  const [currentAlert, setCurrentAlert] = useState<ToastAlert | null>(null);
  const [hasUnreadAlerts, setHasUnreadAlerts] = useState<boolean>(false);

  const prevLiveSnapshotRef = useRef<
    Record<number, { status: string; home: string; away: string; hasScore: boolean; delayed: boolean }> | null
  >(null);
  const activeConcoursRef = useRef<WeeklyConcours>(weeklyConcours);
  activeConcoursRef.current = weeklyConcours;

  // Show clean 3D Promosport logo + fiery spinning ball + radiant gilded MB landing stage on app open (stays until user clicks logo)
  const [showLandingIntro, setShowLandingIntro] = useState<boolean>(true);
  const [landingClosing, setLandingClosing] = useState<boolean>(false);
  const [introEntryPhase, setIntroEntryPhase] = useState<'idle' | 'waiting' | 'descending'>('idle');
  const enterTimerRef = useRef<number | null>(null);
  const settleTimerRef = useRef<number | null>(null);

  // 10-second animated notification icon (drops from top to center w/ smoke trail, golden aura 10s, returns to top & disappears)
  const [floatingGrilleAlert, setFloatingGrilleAlert] = useState<FloatingGrilleAlertData | null>(null);
  const hasRequestedPermissionRef = useRef<boolean>(false);

  // Opening-screen live alerts feed & clearable dismissed IDs set
  const [introAlertsFeed, setIntroAlertsFeed] = useState<IntroAlertItem[]>([]);
  const [dismissedIntroIds, setDismissedIntroIds] = useState<Set<string>>(() => new Set());
  const prevLiveCatalogScoresRef = useRef<Record<string, { home: number; away: number; status: string }> | null>(null);

  const appendIntroAlert = useCallback((item: IntroAlertItem) => {
    setIntroAlertsFeed((prev) => {
      const filtered = prev.filter((existing) => existing.id !== item.id);
      return [item, ...filtered].slice(0, 15);
    });
  }, []);

  const handleClearIntroAlerts = useCallback((idsToDismiss: string[]) => {
    setIntroAlertsFeed([]);
    if (idsToDismiss.length > 0) {
      setDismissedIntroIds((prev) => {
        const next = new Set(prev);
        for (const id of idsToDismiss) {
          next.add(id);
        }
        return next;
      });
    }
  }, []);

  const handleEnterGrilleFromLogo = useCallback(() => {
    if (!showLandingIntro || landingClosing) return;
    audioService.playClick();
    audioService.playGoldenRipple();
    setLandingClosing(true);

    if (enterTimerRef.current) window.clearTimeout(enterTimerRef.current);
    if (settleTimerRef.current) window.clearTimeout(settleTimerRef.current);

    enterTimerRef.current = window.setTimeout(() => {
      setShowLandingIntro(false);
      setLandingClosing(false);
      setIntroEntryPhase('descending');
      settleTimerRef.current = window.setTimeout(() => {
        setIntroEntryPhase('idle');
      }, 1150);
    }, 260);
  }, [showLandingIntro, landingClosing]);

  // MB icon in Grille header returns cleanly to the opening showcase stage
  const handleReturnToIntroFromMb = useCallback(() => {
    if (enterTimerRef.current) window.clearTimeout(enterTimerRef.current);
    if (settleTimerRef.current) window.clearTimeout(settleTimerRef.current);
    audioService.playClick();
    audioService.playGoldenRipple();
    setLandingClosing(false);
    setShowLandingIntro(true);
  }, []);

  useEffect(() => {
    return () => {
      if (enterTimerRef.current) window.clearTimeout(enterTimerRef.current);
      if (settleTimerRef.current) window.clearTimeout(settleTimerRef.current);
    };
  }, []);

  // Silently ensure VAPID desktop Web Push subscription if already permitted
  useEffect(() => {
    void ensureDesktopPushSubscribed(false);
  }, []);

  // Keep audioService synchronized with all user sound choices & click interaction styles
  useEffect(() => {
    audioService.setSoundEnabled(settings.soundEnabled);
    audioService.setGoalSoundStyle(settings.goalSoundStyle);
    audioService.setClickSoundEnabled(settings.clickSoundEnabled);
    audioService.setClickSoundStyle(settings.clickSoundStyle);
  }, [
    settings.soundEnabled,
    settings.goalSoundStyle,
    settings.clickSoundEnabled,
    settings.clickSoundStyle,
  ]);

  // Helper to dispatch OS device push notification via Service Worker
  const emitPushIfEnabled = useCallback(
    (title: string, body: string, concoursNumber = 0, signature = '', customTag?: string) => {
      if (!settings.pushNotificationsEnabled || typeof window === 'undefined' || !('Notification' in window)) {
        return;
      }
      if (Notification.permission !== 'granted') return;

      const resolvedTag = customTag || `promosport-grille-${concoursNumber || 'live'}`;

      const dispatchViaNotificationApi = () => {
        try {
          const notif = new Notification(title, {
            body,
            icon: '/pwa-192x192.png',
            badge: '/pwa-192x192.png',
            dir: 'rtl',
            lang: 'ar',
            tag: resolvedTag,
          });
          notif.onclick = () => {
            try {
              window.focus();
            } catch {
              // ignore focus errors
            }
            setWeeklyConcoursTab('grille');
            notif.close();
          };
        } catch {
          // ignore notification quota errors
        }
      };

      if ('serviceWorker' in navigator) {
        if (navigator.serviceWorker.controller) {
          navigator.serviceWorker.controller.postMessage({
            type: 'SHOW_NEW_GRILLE_NOTIFICATION',
            title,
            body,
            concoursNumber,
            signature,
            tag: resolvedTag,
          });
          return;
        }
        navigator.serviceWorker.ready
          .then((registration) => {
            if (registration && typeof registration.showNotification === 'function') {
              return registration.showNotification(title, {
                body,
                icon: '/pwa-192x192.png',
                badge: '/pwa-192x192.png',
                dir: 'rtl',
                lang: 'ar',
                tag: resolvedTag,
                silent: false,
                data: {
                  url: '/?openGrille=1',
                  concoursNumber,
                  signature,
                },
              });
            }
            dispatchViaNotificationApi();
            return undefined;
          })
          .catch(() => {
            dispatchViaNotificationApi();
          });
      } else {
        dispatchViaNotificationApi();
      }
    },
    [settings.pushNotificationsEnabled]
  );

  // Trigger the 10-second center-drop animated alert icon for any new notification
  const triggerFloatingAlert = useCallback(
    (concoursNumber: number, title: string, subtitle: string) => {
      setFloatingGrilleAlert({
        id: `grille-beacon-${concoursNumber}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        concoursNumber,
        title,
        cagnotte: subtitle,
        createdAtMs: Date.now(),
      });
    },
    []
  );

  // Announces a genuinely new grille or update once (10s animated center icon + sound + OS push)
  const triggerNewGrilleAnnouncement = useCallback(
    (
      concours: WeeklyConcours,
      options?: { forceTest?: boolean; customTitle?: string; customBody?: string }
    ) => {
      const signature = buildConcoursAlertSignature(concours);
      const lastSeenSig = loadLastNotifiedSignature();

      if (!options?.forceTest && lastSeenSig === signature) {
        return false;
      }

      if (!options?.forceTest) {
        saveLastNotifiedSignature(signature, concours.number);
      }

      const timeStr = new Date().toLocaleTimeString('ar-TN', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      });
      const title = options?.customTitle || `قصاصة جديدة رقم ${concours.number}`;
      const message =
        options?.customBody ||
        `الجائزة الكبرى ${concours.cagnotteEstimate} — انقر على الأيقونة لفتح القصاصة فوراً.`;

      triggerFloatingAlert(concours.number, title, concours.cagnotteEstimate);

      appendIntroAlert({
        id: `intro-grille-${concours.number}-${options?.forceTest ? Date.now() : signature}`,
        kind: 'grille',
        title,
        subtitle: `الجائزة الكبرى ${concours.cagnotteEstimate}`,
        timestamp: timeStr,
        concoursNumber: concours.number,
      });

      setCurrentAlert({
        id: `new-grille-${concours.number}-${Date.now()}`,
        title,
        message,
        type: 'grille',
        timestamp: timeStr,
      });
      setHasUnreadAlerts(true);

      if (settings.soundEnabled) {
        audioService.playNewGrilleAlert();
      }

      emitPushIfEnabled(
        title,
        message,
        concours.number,
        signature,
        `promosport-grille-${concours.number}`
      );
      return true;
    },
    [settings.soundEnabled, emitPushIfEnabled, triggerFloatingAlert, appendIntroAlert]
  );

  // Synchronizes active concours & Tirage archive from promosport-pronostic.com / /api/promosport/sync
  const syncFromServer = useCallback(
    async (isAuto = false, force = false) => {
      const payload = await fetchPromosportSyncState(force);
      const nowMs = Date.now();
      const timeStr = new Date(nowMs).toLocaleTimeString('ar-TN', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      });

      const currentConcours = activeConcoursRef.current;
      let nextConcours = payload.activeConcours;

      // Auto-rollover: immediately adopt any newer active grille from promosport-pronostic.com
      const didRollover = nextConcours.number > currentConcours.number;
      if (nextConcours.number < currentConcours.number) {
        nextConcours = currentConcours;
      }

      const prevGrilles = grillesRef.current;
      let archivedList = mergeGrilleArchives(payload.grilles, prevGrilles);

      // Always move superseded active grille into Tirage on rollover, even if winnersCount / prizePerWinner haven't published yet
      if (didRollover || isConcoursCompletelyFinished(currentConcours, nowMs)) {
        const existing = archivedList.find((g) => g.number === currentConcours.number);
        const archivedCurrent = archiveConcoursToGrille(currentConcours, existing);
        archivedList = mergeGrilleArchives(archivedList, [archivedCurrent]);
      }

      setGrilles((prev) => {
        if (
          prev.length === archivedList.length &&
          prev.every(
            (pg, i) =>
              pg.number === archivedList[i].number &&
              pg.status === archivedList[i].status &&
              pg.cagnotte === archivedList[i].cagnotte &&
              pg.winnersCount === archivedList[i].winnersCount &&
              pg.prizePerWinner === archivedList[i].prizePerWinner &&
              pg.winnersFormatted === archivedList[i].winnersFormatted
          )
        ) {
          return prev;
        }
        return archivedList;
      });

      if (didRollover || nextConcours.number === currentConcours.number) {
        setWeeklyConcours((prev) => {
          const merged = didRollover
            ? nextConcours
            : mergeConcoursPreservingScores(prev, nextConcours);
          if (
            !didRollover &&
            prev.number === merged.number &&
            prev.matches.length === merged.matches.length &&
            prev.matches.every(
              (pm, idx) =>
                pm.status === merged.matches[idx].status &&
                pm.score === merged.matches[idx].score &&
                pm.liveMinute === merged.matches[idx].liveMinute &&
                pm.isDelayed === merged.matches[idx].isDelayed
            )
          ) {
            return prev;
          }
          saveCachedConcours(merged);
          return merged;
        });
      }

      if (didRollover) {
        setAppSettings((prev) => {
          if (prev.concoursNumber === nextConcours.number) return prev;
          const updatedSettings = { ...prev, concoursNumber: nextConcours.number };
          saveAppSettings(updatedSettings);
          return updatedSettings;
        });
        prevLiveSnapshotRef.current = null;
      }

      const announcedNewGrille = settings.notifyNewGrille
        ? triggerNewGrilleAnnouncement(nextConcours, {
            customTitle: didRollover
              ? `تم تنزيل القصاصة الجديدة رقم ${nextConcours.number}`
              : undefined,
            customBody: didRollover
              ? `تم تحويل القصاصة ${currentConcours.number} إلى خانة Tirage وتفعيل القصاصة ${nextConcours.number} (${nextConcours.cagnotteEstimate}).`
              : undefined,
          })
        : false;

      // Detect first publication of financial value ("القيمة المالية"), winnersCount ("عدد المرابيح"), and share ("نصيب كل فائز") on recent Tirage grille
      let announcedWinners = false;
      const notifiedWinners = loadNotifiedWinnersMap();
      const recentArchived = archivedList
        .filter((g) => g.number < nextConcours.number)
        .sort((a, b) => b.number - a.number);

      for (const g of recentArchived) {
        const hasPayoutsPublished =
          g.status === 'official' &&
          g.winnersFormatted &&
          g.winnersFormatted !== 'قيد التحديد الرسمي';
        const hasCagnottePublished = g.cagnotte > 0 && g.cagnotteFormatted !== 'قيد التحديد الرسمي';

        if (hasPayoutsPublished || hasCagnottePublished) {
          const winSig = `${g.number}:${g.cagnotte}:${g.winnersCount}:${g.prizePerWinner}:${g.status}`;
          const prevRecorded = notifiedWinners[g.number];
          const wasPendingInUi = prevGrilles.some((pg) => pg.number === g.number && pg.status === 'pending');

          if (prevRecorded !== winSig) {
            saveNotifiedWinnersSignature(g.number, winSig);
            const isNewestTirage = recentArchived[0]?.number === g.number;
            if ((isNewestTirage || wasPendingInUi) && settings.notifyOfficialResults && !announcedWinners) {
              announcedWinners = true;
              const wTitle = hasPayoutsPublished
                ? `إعلان القيمة المالية والمرابيح — القصاصة ${g.number}`
                : `تحديث القيمة المالية — القصاصة ${g.number}`;
              const wMsg = hasPayoutsPublished
                ? `القيمة المالية: ${g.cagnotteFormatted} • المرابيح: ${g.winnersFormatted} • نصيب كل فائز: ${g.prizePerWinnerFormatted}`
                : `القيمة المالية: ${g.cagnotteFormatted} — بقية القصاصة ثابتة كصورة مجمدة`;
              triggerFloatingAlert(
                g.number,
                wTitle,
                hasPayoutsPublished
                  ? `${g.cagnotteFormatted} | ${g.winnersFormatted} | ${g.prizePerWinnerFormatted}`
                  : g.cagnotteFormatted
              );
              appendIntroAlert({
                id: `intro-winners-${g.number}-${winSig}`,
                kind: 'winners',
                title: wTitle,
                subtitle: wMsg,
                timestamp: timeStr,
                concoursNumber: g.number,
              });
              setCurrentAlert({
                id: `winners-${g.number}-${Date.now()}`,
                title: wTitle,
                message: wMsg,
                type: 'result',
                timestamp: timeStr,
              });
              setHasUnreadAlerts(true);
              if (settings.soundEnabled) {
                audioService.playChime();
              }
              emitPushIfEnabled(wTitle, wMsg, g.number, winSig, `promosport-winners-${g.number}`);
            }
          }
        }
      }

      if (!announcedNewGrille && !announcedWinners && isAuto && settings.notifyOfficialResults) {
        const title = 'تحيين دوري ناجح';
        const message = `تحديث دوري (كل ${settings.checkIntervalMinutes} دقيقة) — القصاصة ${nextConcours.number} (${nextConcours.cagnotteEstimate}).`;
        triggerFloatingAlert(nextConcours.number, title, nextConcours.cagnotteEstimate);
        setCurrentAlert({
          id: `sync-${Date.now()}`,
          title,
          message,
          type: 'result',
          timestamp: timeStr,
        });
        setHasUnreadAlerts(true);
        if (settings.soundEnabled) {
          audioService.playChime();
        }
        emitPushIfEnabled(title, message, nextConcours.number);
      }
    },
    [
      settings.notifyNewGrille,
      settings.notifyOfficialResults,
      settings.checkIntervalMinutes,
      settings.soundEnabled,
      emitPushIfEnabled,
      triggerNewGrilleAnnouncement,
      triggerFloatingAlert,
      appendIntroAlert,
    ]
  );

  // Initial sync with server on mount & handle deep-link ?openGrille=1 / ?openSettings=1
  useEffect(() => {
    void syncFromServer(false, true);

    try {
      const params = new URLSearchParams(window.location.search);
      if (params.get('openSettings') === '1') {
        setWeeklyConcoursTab('settings');
        setShowLandingIntro(false);
        params.delete('openSettings');
      } else if (params.get('openGrille') === '1') {
        setWeeklyConcoursTab('grille');
        setShowLandingIntro(false);
        params.delete('openGrille');
      }
      const nextUrl =
        window.location.pathname + (params.toString() ? `?${params.toString()}` : '') + window.location.hash;
      window.history.replaceState({}, '', nextUrl);
    } catch {
      // ignore URL parsing errors
    }
  }, []);

  // Automatically ensure device Notification permission & listen for wake-from-idle + Service Worker messages
  useEffect(() => {
    const requestPermissionOnFirstGesture = () => {
      if (hasRequestedPermissionRef.current) return;
      hasRequestedPermissionRef.current = true;
      if (settings.pushNotificationsEnabled && typeof window !== 'undefined' && 'Notification' in window) {
        void ensureDesktopPushSubscribed(Notification.permission === 'default')
          .then(({ permission }) => {
            if (permission === 'granted') {
              const current = activeConcoursRef.current;
              const sig = buildConcoursAlertSignature(current);
              saveLastNotifiedSignature(sig, current.number);
            }
          })
          .catch(() => {});
      }
    };

    window.addEventListener('pointerdown', requestPermissionOnFirstGesture, { once: true, passive: true });

    const handleWakeSync = () => {
      if (document.visibilityState === 'visible') {
        void syncFromServer(false, true);
      }
    };

    const handleFocusOrOnline = () => {
      void syncFromServer(false, true);
    };

    document.addEventListener('visibilitychange', handleWakeSync);
    window.addEventListener('focus', handleFocusOrOnline);
    window.addEventListener('online', handleFocusOrOnline);

    const handleSwMessage = (event: MessageEvent) => {
      const data = event.data;
      if (!data || typeof data !== 'object') return;
      if (data.type === 'OPEN_GRILLE_FROM_NOTIFICATION') {
        setFloatingGrilleAlert(null);
        setShowLandingIntro(false);
        setWeeklyConcoursTab('grille');
      } else if (data.type === 'NEW_GRILLE_DETECTED' && data.concours) {
        setWeeklyConcours(data.concours as WeeklyConcours);
        if (settings.notifyNewGrille) {
          triggerNewGrilleAnnouncement(data.concours as WeeklyConcours, { forceTest: true });
          if (typeof data.signature === 'string') {
            saveLastNotifiedSignature(data.signature, (data.concours as WeeklyConcours).number);
          }
        }
      }
    };

    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.addEventListener('message', handleSwMessage);
    }

    return () => {
      window.removeEventListener('pointerdown', requestPermissionOnFirstGesture);
      document.removeEventListener('visibilitychange', handleWakeSync);
      window.removeEventListener('focus', handleFocusOrOnline);
      window.removeEventListener('online', handleFocusOrOnline);
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.removeEventListener('message', handleSwMessage);
      }
    };
  }, [settings.pushNotificationsEnabled, settings.notifyNewGrille, syncFromServer, triggerNewGrilleAnnouncement]);

  // Reactive live goal, kickoff & full-time monitor whenever concours updates
  useEffect(() => {
    const now = Date.now();
    const evaluated = evaluateConcoursRealTime(weeklyConcours, now);
    const timeStr = new Date(now).toLocaleTimeString('ar-TN', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });

    const nextSnapshot: Record<
      number,
      { status: string; home: string; away: string; hasScore: boolean; delayed: boolean }
    > = {};
    evaluated.matches.forEach((m) => {
      const hasScore =
        !m.isDelayed &&
        m.scoreHome !== undefined &&
        m.scoreAway !== undefined &&
        /^\d+$/.test(String(m.scoreHome)) &&
        /^\d+$/.test(String(m.scoreAway));
      nextSnapshot[m.id] = {
        status: m.status,
        home: hasScore ? String(m.scoreHome) : '',
        away: hasScore ? String(m.scoreAway) : '',
        hasScore,
        delayed: Boolean(m.isDelayed),
      };
    });

    const prevSnapshot = prevLiveSnapshotRef.current;
    if (prevSnapshot) {
      for (const m of evaluated.matches) {
        const prev = prevSnapshot[m.id];
        const curSnap = nextSnapshot[m.id];
        if (!prev || !curSnap || curSnap.delayed) continue;

        const curH = Number(curSnap.home || 0);
        const curA = Number(curSnap.away || 0);
        const prevH = Number(prev.home || 0);
        const prevA = Number(prev.away || 0);

        // 1. Live Goal Scored Event (only on verified score increase)
        if (
          curSnap.hasScore &&
          (m.status === 'live' || (prev.status === 'live' && m.status === 'finished')) &&
          ((prev.hasScore && (curH > prevH || curA > prevA)) || (!prev.hasScore && (curH > 0 || curA > 0)))
        ) {
          const title = `هدف مسجل الآن! (${m.homeTeam} ${curSnap.home} - ${curSnap.away} ${m.awayTeam})`;
          const message = `تحديث فوري مباشر • الدقيقة ${m.liveMinute || "1'"} — القصاصة رقم ${evaluated.number}`;
          const goalTag = `goal-${evaluated.number}-${m.id}-${curSnap.home}-${curSnap.away}`;
          triggerFloatingAlert(evaluated.number, title, `${curSnap.home} - ${curSnap.away}`);
          appendIntroAlert({
            id: `intro-${goalTag}`,
            kind: 'goal',
            title,
            subtitle: message,
            timestamp: timeStr,
            concoursNumber: evaluated.number,
            scoreLabel: `${curSnap.home} - ${curSnap.away}`,
          });
          setCurrentAlert({
            id: `goal-${m.id}-${Date.now()}`,
            title,
            message,
            type: 'golden',
            timestamp: timeStr,
          });
          setHasUnreadAlerts(true);
          if (settings.soundEnabled) audioService.playGoalAlert();
          emitPushIfEnabled(title, message, evaluated.number, goalTag, goalTag);
        }
        // 2. Kickoff Started Event (strictly from verified live feed)
        else if (prev.status === 'scheduled' && m.status === 'live' && curSnap.hasScore) {
          const title = `انطلاق المقابلة #${m.id}: ${m.homeTeam} ضد ${m.awayTeam}`;
          const message = `بدأت المقابلة الآن (${curSnap.home} - ${curSnap.away}) مع التحديث المباشر.`;
          const kickoffTag = `kickoff-${evaluated.number}-${m.id}`;
          triggerFloatingAlert(evaluated.number, title, `مباشر الآن ${curSnap.home} - ${curSnap.away}`);
          appendIntroAlert({
            id: `intro-${kickoffTag}`,
            kind: 'kickoff',
            title,
            subtitle: message,
            timestamp: timeStr,
            concoursNumber: evaluated.number,
            scoreLabel: `${curSnap.home} - ${curSnap.away}`,
          });
          setCurrentAlert({
            id: `kickoff-${m.id}-${Date.now()}`,
            title,
            message,
            type: 'result',
            timestamp: timeStr,
          });
          setHasUnreadAlerts(true);
          if (settings.soundEnabled) audioService.playWhistle();
          emitPushIfEnabled(title, message, evaluated.number, kickoffTag, kickoffTag);
        }
        // 3. Match Full-Time Event (strictly from verified finished score)
        else if (prev.status !== 'finished' && m.status === 'finished' && curSnap.hasScore) {
          const title = `نهاية المقابلة #${m.id}: ${m.homeTeam} ${curSnap.home} - ${curSnap.away} ${m.awayTeam}`;
          const message = `النتيجة النهائية: ${m.result || '-'} • مسابقة رقم ${evaluated.number}`;
          const ftTag = `ft-${evaluated.number}-${m.id}`;
          if (settings.notifyOfficialResults) {
            triggerFloatingAlert(evaluated.number, title, `FT ${curSnap.home} - ${curSnap.away}`);
            appendIntroAlert({
              id: `intro-${ftTag}`,
              kind: 'result',
              title,
              subtitle: message,
              timestamp: timeStr,
              concoursNumber: evaluated.number,
              scoreLabel: `${curSnap.home} - ${curSnap.away}`,
            });
            setCurrentAlert({
              id: `ft-${m.id}-${Date.now()}`,
              title,
              message,
              type: 'result',
              timestamp: timeStr,
            });
            setHasUnreadAlerts(true);
            if (settings.soundEnabled) audioService.playChime();
            emitPushIfEnabled(title, message, evaluated.number, ftTag, ftTag);
          }
        }
      }
    }

    prevLiveSnapshotRef.current = nextSnapshot;
  }, [weeklyConcours, settings.soundEnabled, settings.notifyOfficialResults, emitPushIfEnabled, triggerFloatingAlert, appendIntroAlert]);

  // Lightweight 10-second live sync polling (replaces heavy 1-second timer)
  useEffect(() => {
    const syncId = window.setInterval(() => {
      void syncFromServer(false, false);
    }, 10000);
    return () => window.clearInterval(syncId);
  }, [syncFromServer]);

  // Background watcher for live goal alerts across the real-time matches catalog
  useEffect(() => {
    let active = true;
    const pollLiveCatalogGoals = async () => {
      try {
        const scan = await fetchPromosportLiveMatchesScan(false);
        if (!active || !scan || !Array.isArray(scan.matches)) return;

        const nextScores: Record<string, { home: number; away: number; status: string }> = {};
        const prevScores = prevLiveCatalogScoresRef.current;
        const timeStr = new Date().toLocaleTimeString('ar-TN', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        });

        for (const m of scan.matches) {
          if (!m.hasVerifiedScore || m.scoreHome === undefined || m.scoreAway === undefined) continue;
          const homeStr = String(m.scoreHome).trim();
          const awayStr = String(m.scoreAway).trim();
          if (!/^\d+$/.test(homeStr) || !/^\d+$/.test(awayStr)) continue;
          const curH = Number(homeStr);
          const curA = Number(awayStr);
          const matchKey = m.siteMatchId || `${m.id}-${m.homeTeam}`;
          nextScores[matchKey] = { home: curH, away: curA, status: m.status };

          if (prevScores && prevScores[matchKey] && m.status === 'live') {
            const prev = prevScores[matchKey];
            if (curH > prev.home || curA > prev.away) {
              const scoreLabel = `${curH} - ${curA}`;
              const title = `هدف مباشر! ${m.homeTeam} ${scoreLabel} ${m.awayTeam}`;
              const message = `${m.leagueName || 'المباريات المباشرة'} • الدقيقة ${m.liveMinute || "1'"}`;
              const goalTag = `live-goal-${matchKey}-${curH}-${curA}`;

              appendIntroAlert({
                id: `intro-${goalTag}`,
                kind: 'goal',
                title,
                subtitle: message,
                timestamp: timeStr,
                scoreLabel,
              });
              triggerFloatingAlert(activeConcoursRef.current.number, title, scoreLabel);
              setCurrentAlert({
                id: `${goalTag}-${Date.now()}`,
                title,
                message,
                type: 'golden',
                timestamp: timeStr,
              });
              setHasUnreadAlerts(true);
              if (settings.soundEnabled) audioService.playGoalAlert();
              emitPushIfEnabled(title, message, activeConcoursRef.current.number, goalTag, goalTag);
            }
          }
        }

        prevLiveCatalogScoresRef.current = nextScores;
      } catch {
        // ignore transient network errors
      }
    };

    void pollLiveCatalogGoals();
    const id = window.setInterval(() => {
      void pollLiveCatalogGoals();
    }, 25000);

    return () => {
      active = false;
      window.clearInterval(id);
    };
  }, [appendIntroAlert, emitPushIfEnabled, settings.soundEnabled, triggerFloatingAlert]);

  // Periodic automated sync check for new concours based on checkIntervalMinutes (15 / 30 / 60 min)
  useEffect(() => {
    if (!settings.autoUpdateActive) return;

    const intervalMs = settings.checkIntervalMinutes * 60 * 1000;
    const intervalId = setInterval(() => {
      void syncFromServer(true, true);
    }, intervalMs);

    return () => clearInterval(intervalId);
  }, [settings.autoUpdateActive, settings.checkIntervalMinutes, syncFromServer]);

  const handleImmediateUpdateSettings = useCallback((newSettings: NotificationSettings) => {
    setSettings(newSettings);
    saveSettings(newSettings);
    audioService.setSoundEnabled(newSettings.soundEnabled);
    audioService.setGoalSoundStyle(newSettings.goalSoundStyle);
    audioService.setClickSoundEnabled(newSettings.clickSoundEnabled);
    audioService.setClickSoundStyle(newSettings.clickSoundStyle);
  }, []);

  const handleSaveSettings = (newSettings: NotificationSettings) => {
    handleImmediateUpdateSettings(newSettings);

    setCurrentAlert({
      id: `saved-${Date.now()}`,
      title: 'تم حفظ وتفعيل منظومة التحديثات بنجاح',
      message: `${
        newSettings.autoUpdateActive
          ? `فحص القصاصات الجديدة كل ${newSettings.checkIntervalMinutes} دقيقة`
          : 'التحديث التلقائي للقصاصات متوقف'
      } • التحديث المباشر كل ثانية مفعل دوماً.`,
      type: 'system',
      timestamp: new Date().toLocaleTimeString('ar-TN', { hour: '2-digit', minute: '2-digit' }),
    });
  };

  const handleTriggerTestAlert = () => {
    setIsNotificationsOpen(false);
    triggerNewGrilleAnnouncement(weeklyConcours, {
      forceTest: true,
      customTitle: `إشعار قصاصة جديدة رقم ${weeklyConcours.number}`,
      customBody: `الجائزة الكبرى ${weeklyConcours.cagnotteEstimate} — تنبيه حي في التطبيق وإشعارات الجهاز.`,
    });
  };

  const handleStableRefreshSync = useCallback(() => {
    return syncFromServer(false, true);
  }, [syncFromServer]);

  const handleCloseModalToGrille = useCallback(() => {
    setWeeklyConcoursTab('grille');
  }, []);

  const handleUpdateAppSettings = useCallback((updated: AppSettings) => {
    setAppSettings(updated);
    saveAppSettings(updated);
  }, []);

  const handleOpenNotifications = useCallback(() => {
    setHasUnreadAlerts(false);
    setIsNotificationsOpen(true);
  }, []);

  return (
    <div className="relative w-full screen-h-full overflow-hidden bg-[#020612] select-none">
      {/* Opening Showcase: 3D Fiery Ball & Living Flame + Clearable Live Alerts Strip below PROMOSPORT */}
      <PromosportIntroStage
        active={showLandingIntro}
        isClosing={landingClosing}
        onEnterGrille={handleEnterGrilleFromLogo}
        concours={weeklyConcours}
        alertsFeed={introAlertsFeed}
        dismissedIds={dismissedIntroIds}
        onClearAlerts={handleClearIntroAlerts}
      />

      {/* Main App Interface: خانة القصاصة (mounted cleanly once user enters via logo) */}
      {!showLandingIntro && (
        <WeeklyConcoursModal
          isOpen={true}
          asMainPage={true}
          onClose={handleCloseModalToGrille}
          onOpenIntroStage={handleReturnToIntroFromMb}
          concours={weeklyConcours}
          onUpdateConcours={setWeeklyConcours}
          grilles={grilles}
          onRefreshSync={handleStableRefreshSync}
          initialTab={weeklyConcoursTab}
          onTabChange={setWeeklyConcoursTab}
          externalEntryPhase={introEntryPhase}
          appSettings={appSettings}
          onUpdateAppSettings={handleUpdateAppSettings}
          onOpenNotifications={handleOpenNotifications}
          hasUnreadAlerts={hasUnreadAlerts}
        />
      )}

      {/* 10-Second Animated Floating Alert Icon (drops from top to center w/ smoke trail, golden aura 10s, returns to top & disappears) */}
      <FloatingGrilleAlertBadge
        alert={floatingGrilleAlert}
        onOpenGrille={() => {
          setFloatingGrilleAlert(null);
          setShowLandingIntro(false);
          setWeeklyConcoursTab('grille');
        }}
        onExpire={() => setFloatingGrilleAlert(null)}
      />

      {/* Toast Alert Notification */}
      <ToastNotification
        alert={currentAlert}
        onDismiss={() => setCurrentAlert(null)}
        durationSeconds={settings.durationSeconds}
      />

      {/* Advanced Notification System Modal */}
      <NotificationModal
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        settings={settings}
        onImmediateApply={handleImmediateUpdateSettings}
        onSaveSettings={handleSaveSettings}
        onTriggerTestAlert={handleTriggerTestAlert}
      />

      {/* PWA Install Prompt & Offline Indicator */}
      <PWAInstallButton
        onOpenInstallHub={() => {
          setWeeklyConcoursTab('apk');
        }}
      />
      <OfflineIndicator />
    </div>
  );
}
