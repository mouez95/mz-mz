/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import React from 'react';
import { CheckCircle2, Download, Smartphone, WifiOff } from 'lucide-react';
import type { AppSettings, UserBetSlip, WeeklyConcours } from '../types/promosport';
import { PWAInstallButton } from './PWAInstallControls';

interface AppInstallPromptHubProps {
  settings: AppSettings;
  userSlips: UserBetSlip[];
  concours: WeeklyConcours;
}

/**
 * Central installation panel used by the protected APK/PWA tab.
 * It deliberately exposes only installation paths that are available at runtime:
 * the browser's install prompt and the Android WebView/Capacitor build itself.
 */
export const AppInstallPromptHub: React.FC<AppInstallPromptHubProps> = ({
  settings,
  userSlips,
  concours,
}) => {
  const canUseBrowserInstall = typeof window !== 'undefined' && 'serviceWorker' in navigator;

  return (
    <section
      dir="rtl"
      aria-label="مركز تثبيت التطبيق"
      className="rounded-2xl border border-cyan-400/40 bg-[#06142b]/90 p-4 text-white shadow-[0_0_24px_rgba(14,165,233,0.2)]"
    >
      <div className="flex items-start gap-3">
        <div className="rounded-xl bg-cyan-400/15 p-2 text-cyan-300">
          <Smartphone className="h-6 w-6" />
        </div>
        <div className="min-w-0 flex-1">
          <h3 className="text-sm font-black text-yellow-300">تثبيت {settings.appName}</h3>
          <p className="mt-1 text-xs leading-5 text-slate-200">
            استخدم زر التثبيت إذا عرضه المتصفح. تحفظ القصاصات محليًا وتعمل البيانات المحفوظة دون اتصال.
          </p>
        </div>
      </div>

      <div className="mt-3 grid gap-2 text-[11px] text-slate-200 sm:grid-cols-2">
        <div className="rounded-xl border border-emerald-400/25 bg-emerald-500/10 p-2.5">
          <div className="flex items-center gap-1.5 font-bold text-emerald-300">
            <CheckCircle2 className="h-4 w-4" />
            <span>حالة التطبيق</span>
          </div>
          <p className="mt-1">القصاصة الحالية #{concours.number} • {userSlips.length} قصاصة محفوظة</p>
        </div>
        <div className="rounded-xl border border-sky-400/25 bg-sky-500/10 p-2.5">
          <div className="flex items-center gap-1.5 font-bold text-sky-300">
            <WifiOff className="h-4 w-4" />
            <span>وضع عدم الاتصال</span>
          </div>
          <p className="mt-1">يعمل بعد تحميل التطبيق مرة واحدة في Chrome.</p>
        </div>
      </div>

      {canUseBrowserInstall ? (
        <div className="mt-3 rounded-xl border border-yellow-400/30 bg-yellow-400/10 p-2.5">
          <div className="mb-2 flex items-center gap-1.5 text-xs font-black text-yellow-200">
            <Download className="h-4 w-4" />
            <span>التثبيت الرسمي المتاح لهذا الجهاز</span>
          </div>
          <PWAInstallButton />
          <p className="mt-2 text-[11px] leading-5 text-slate-300">
            إذا لم يظهر الزر، افتح قائمة Chrome ثم اختر «تثبيت التطبيق» أو «إضافة إلى الشاشة الرئيسية».
          </p>
        </div>
      ) : (
        <p className="mt-3 rounded-xl border border-amber-400/30 bg-amber-400/10 p-2.5 text-[11px] leading-5 text-amber-100">
          افتح التطبيق في Chrome أو ثبّت نسخة Android APK المبنية من مجلد android للحصول على التثبيت الأصلي.
        </p>
      )}
    </section>
  );
};
