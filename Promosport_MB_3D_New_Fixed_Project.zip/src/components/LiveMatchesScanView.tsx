/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import {
  Radar,
  Radio,
  Star,
  Tv,
  Search,
  RefreshCw,
  ArrowUpDown,
  Trophy,
  Globe2,
  Filter,
} from 'lucide-react';
import { SiteLiveMatch, SiteLiveLeagueSummary } from '../types/promosport';
import { fetchPromosportLiveMatchesScan } from '../services/promosportData';
import {
  loadLiveFavoriteMatchIds,
  saveLiveFavoriteMatchIds,
  loadLiveFavoriteLeagues,
  saveLiveFavoriteLeagues,
  loadLiveWatchMatchIds,
  saveLiveWatchMatchIds,
  loadLiveAlwaysOn,
  saveLiveAlwaysOn,
} from '../services/storageService';
import { audioService } from '../services/audioService';
import { PinterestScoreboardCard } from './PinterestScoreboardCard';

interface LiveMatchesScanViewProps {
  lang: 'AR' | 'FR';
  getTeamName?: (teamName: string, frName?: string) => string;
  onLiveCountChange?: (liveCount: number) => void;
}

type LiveFilterTab = 'all' | 'live' | 'watch' | 'favorites';
type LeagueSortMode = 'league-priority' | 'live-first' | 'time';

const INVALID_STATUS_CODES = new Set(['PST', 'PPD', 'CANC', 'SUSP', 'ABD', 'AWD', 'INT', 'WO', 'DELAYED']);

function isMatchValidForDisplay(m: SiteLiveMatch): boolean {
  if (m.isDelayed) return false;
  const st = String(m.statusCode || '').trim().toUpperCase();
  if (INVALID_STATUS_CODES.has(st)) return false;
  if (!m.homeTeam || !m.awayTeam) return false;
  if (m.status === 'live' || m.status === 'finished') {
    return (
      m.hasVerifiedScore &&
      m.scoreHome !== undefined &&
      m.scoreAway !== undefined &&
      /^\d+$/.test(String(m.scoreHome)) &&
      /^\d+$/.test(String(m.scoreAway))
    );
  }
  return true;
}

function advanceMinuteTick(minuteText: string | undefined, steps: number): string | undefined {
  if (!minuteText || steps <= 0) return minuteText;
  const trimmed = minuteText.trim();
  if (/^(HT|FT|PAUSE|MT)$/i.test(trimmed)) return trimmed;
  const numMatch = trimmed.match(/^(\d{1,3})/);
  if (!numMatch) return trimmed;
  const baseMin = Number(numMatch[1]);
  if (!Number.isFinite(baseMin)) return trimmed;
  const isFirstHalf = /1H/i.test(trimmed) || baseMin <= 45;
  const cap = isFirstHalf ? 45 : 90;
  const nextMin = Math.min(cap, baseMin + steps);
  const suffix = trimmed.replace(/^\d{1,3}'?/, '').trim();
  return suffix ? `${nextMin}' ${suffix}` : `${nextMin}'`;
}

export const LiveMatchesScanView: React.FC<LiveMatchesScanViewProps> = ({
  lang,
  getTeamName,
  onLiveCountChange,
}) => {
  const [matches, setMatches] = useState<SiteLiveMatch[]>([]);
  const [leagues, setLeagues] = useState<SiteLiveLeagueSummary[]>([]);
  const [scannedAt, setScannedAt] = useState<string>('');
  const [isScanning, setIsScanning] = useState<boolean>(true);
  const [scanError, setScanError] = useState<string | null>(null);

  const [alwaysLiveActive, setAlwaysLiveActive] = useState<boolean>(() => loadLiveAlwaysOn());
  const [filterTab, setFilterTab] = useState<LiveFilterTab>('all');
  const [sortMode, setSortMode] = useState<LeagueSortMode>('league-priority');
  const [selectedLeagueKey, setSelectedLeagueKey] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const [favoriteMatchIds, setFavoriteMatchIds] = useState<string[]>(() => loadLiveFavoriteMatchIds());
  const [favoriteLeagues, setFavoriteLeagues] = useState<string[]>(() => loadLiveFavoriteLeagues());
  const [watchMatchIds, setWatchMatchIds] = useState<string[]>(() => loadLiveWatchMatchIds());

  const [goalFlashMap, setGoalFlashMap] = useState<Record<string, number>>({});
  const [failedImages, setFailedImages] = useState<Record<string, boolean>>({});
  const [minuteStepsSincePoll, setMinuteStepsSincePoll] = useState<number>(0);

  const prevScoreMapRef = useRef<Record<string, { h: number; a: number; hasScore: boolean; status: string }> | null>(
    null
  );
  const mountedRef = useRef<boolean>(true);
  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
    };
  }, []);

  const performScan = useCallback(async (forceScan: boolean, silent = false) => {
    if (!silent) {
      setIsScanning(true);
    }
    try {
      const payload = await fetchPromosportLiveMatchesScan(forceScan);
      if (!mountedRef.current) return;

      if (payload && Array.isArray(payload.matches)) {
        const cleanMatches = payload.matches.filter(isMatchValidForDisplay);
        setMatches(cleanMatches);
        setLeagues(payload.leagues || []);
        setScannedAt(payload.scannedAt || new Date().toISOString());
        setMinuteStepsSincePoll(0);
        setScanError(null);
      } else if (!silent) {
        setScanError('تعذر الاتصال بنطاق promosport-pronostic.com حالياً — جارٍ إعادة المحاولة.');
      }
    } catch {
      if (mountedRef.current && !silent) {
        setScanError('تعذر مسح النطاق المباشر — تحقق من الاتصال.');
      }
    } finally {
      if (mountedRef.current) {
        setIsScanning(false);
      }
    }
  }, []);

  // Initial domain scan on mount
  useEffect(() => {
    void performScan(true, false);
  }, [performScan]);

  // Always-live continuous moment-by-moment polling (every 3 seconds when enabled)
  useEffect(() => {
    if (!alwaysLiveActive) return;
    const pollId = window.setInterval(() => {
      void performScan(false, true);
    }, 3000);
    return () => window.clearInterval(pollId);
  }, [alwaysLiveActive, performScan]);

  // Smooth minute ticker between server updates while Always-Live is ON
  useEffect(() => {
    if (!alwaysLiveActive) return;
    const tickId = window.setInterval(() => {
      setMinuteStepsSincePoll((s) => (s < 3 ? s + 1 : s));
    }, 20000);
    return () => window.clearInterval(tickId);
  }, [alwaysLiveActive]);

  // Detect verified goals on live / watched matches and play chime + 7s flame ring
  useEffect(() => {
    const nextMap: Record<string, { h: number; a: number; hasScore: boolean; status: string }> = {};
    const newlyScoredIds: string[] = [];

    for (const m of matches) {
      const hasScore =
        m.hasVerifiedScore &&
        m.scoreHome !== undefined &&
        m.scoreAway !== undefined &&
        /^\d+$/.test(String(m.scoreHome)) &&
        /^\d+$/.test(String(m.scoreAway));
      const h = hasScore ? Number(m.scoreHome) : 0;
      const a = hasScore ? Number(m.scoreAway) : 0;
      nextMap[m.siteMatchId] = { h, a, hasScore, status: m.status };

      const prev = prevScoreMapRef.current?.[m.siteMatchId];
      if (
        prev &&
        hasScore &&
        (m.status === 'live' || (prev.status === 'live' && m.status === 'finished')) &&
        ((prev.hasScore && (h > prev.h || a > prev.a)) || (!prev.hasScore && (h > 0 || a > 0)))
      ) {
        newlyScoredIds.push(m.siteMatchId);
      }
    }

    prevScoreMapRef.current = nextMap;

    if (newlyScoredIds.length > 0) {
      audioService.playGoalAlert();
      const stamp = Date.now();
      setGoalFlashMap((prev) => {
        const updated = { ...prev };
        newlyScoredIds.forEach((id) => {
          updated[id] = stamp;
        });
        return updated;
      });
      newlyScoredIds.forEach((id) => {
        window.setTimeout(() => {
          setGoalFlashMap((prev) => {
            if (prev[id] !== stamp) return prev;
            const copy = { ...prev };
            delete copy[id];
            return copy;
          });
        }, 7000);
      });
    }
  }, [matches]);

  const favMatchSet = useMemo(() => new Set(favoriteMatchIds), [favoriteMatchIds]);
  const favLeagueSet = useMemo(() => new Set(favoriteLeagues), [favoriteLeagues]);
  const watchSet = useMemo(() => new Set(watchMatchIds), [watchMatchIds]);

  const liveMatchesCount = useMemo(
    () => matches.filter((m) => m.status === 'live').length,
    [matches]
  );

  useEffect(() => {
    onLiveCountChange?.(liveMatchesCount);
  }, [liveMatchesCount, onLiveCountChange]);

  const toggleFavoriteMatch = (siteMatchId: string) => {
    audioService.playClick();
    setFavoriteMatchIds((prev) => {
      const exists = prev.includes(siteMatchId);
      const next = exists ? prev.filter((id) => id !== siteMatchId) : [...prev, siteMatchId];
      saveLiveFavoriteMatchIds(next);
      return next;
    });
  };

  const toggleFavoriteLeague = (leagueKey: string) => {
    audioService.playClick();
    setFavoriteLeagues((prev) => {
      const exists = prev.includes(leagueKey);
      const next = exists ? prev.filter((k) => k !== leagueKey) : [...prev, leagueKey];
      saveLiveFavoriteLeagues(next);
      return next;
    });
  };

  const toggleWatchLiveMatch = (siteMatchId: string) => {
    audioService.playClick();
    setWatchMatchIds((prev) => {
      const exists = prev.includes(siteMatchId);
      const next = exists ? prev.filter((id) => id !== siteMatchId) : [...prev, siteMatchId];
      saveLiveWatchMatchIds(next);
      return next;
    });
  };

  const toggleAlwaysLive = () => {
    audioService.playClick();
    setAlwaysLiveActive((prev) => {
      const next = !prev;
      saveLiveAlwaysOn(next);
      if (next) {
        void performScan(true, true);
      }
      return next;
    });
  };

  const normalizedSearch = searchQuery.trim().toLowerCase();

  // Matches filtered by tab, league dropdown, and search
  const filteredMatches = useMemo(() => {
    return matches.filter((m) => {
      if (filterTab === 'live' && m.status !== 'live') return false;
      if (filterTab === 'watch' && !watchSet.has(m.siteMatchId)) return false;
      if (
        filterTab === 'favorites' &&
        !favMatchSet.has(m.siteMatchId) &&
        !favLeagueSet.has(m.leagueKey)
      ) {
        return false;
      }
      if (selectedLeagueKey !== 'ALL' && m.leagueKey !== selectedLeagueKey) return false;

      if (normalizedSearch) {
        const hay = `${m.homeTeam} ${m.homeTeamFr || ''} ${m.awayTeam} ${m.awayTeamFr || ''} ${m.competition || ''} ${m.competitionFr || ''} ${m.countryName}`.toLowerCase();
        if (!hay.includes(normalizedSearch)) return false;
      }
      return true;
    });
  }, [matches, filterTab, watchSet, favMatchSet, favLeagueSet, selectedLeagueKey, normalizedSearch]);

  // Pinned watched matches at top (when user selected matches via "مشاهدة مباشرة")
  const pinnedWatchedMatches = useMemo(() => {
    if (filterTab === 'favorites') return [];
    return matches.filter((m) => {
      if (!watchSet.has(m.siteMatchId)) return false;
      if (filterTab === 'live' && m.status !== 'live') return false;
      if (selectedLeagueKey !== 'ALL' && m.leagueKey !== selectedLeagueKey) return false;
      return true;
    });
  }, [matches, watchSet, filterTab, selectedLeagueKey]);

  // League metadata lookup
  const leagueMetaMap = useMemo(() => {
    const map = new Map<string, SiteLiveLeagueSummary>();
    for (const l of leagues) {
      map.set(l.leagueKey, l);
    }
    return map;
  }, [leagues]);

  // Group filtered matches by league and order leagues cleanly (`ترتيب الدوريات`)
  const orderedLeagueGroups = useMemo(() => {
    const groupsMap = new Map<
      string,
      {
        leagueKey: string;
        meta: SiteLiveLeagueSummary;
        matches: SiteLiveMatch[];
        liveInGroup: number;
      }
    >();

    for (const m of filteredMatches) {
      let group = groupsMap.get(m.leagueKey);
      if (!group) {
        const meta: SiteLiveLeagueSummary = leagueMetaMap.get(m.leagueKey) || {
          leagueKey: m.leagueKey,
          countryName: m.countryName,
          countryAr: m.countryName,
          leagueName: m.leagueName,
          countryFlagUrl: m.countryFlagUrl,
          leagueLogoUrl: m.leagueLogoUrl,
          rank: m.leagueOrderRank,
          totalCount: 0,
          liveCount: 0,
        };
        group = {
          leagueKey: m.leagueKey,
          meta,
          matches: [],
          liveInGroup: 0,
        };
        groupsMap.set(m.leagueKey, group);
      }
      group.matches.push(m);
      if (m.status === 'live') {
        group.liveInGroup += 1;
      }
    }

    const groups = Array.from(groupsMap.values());

    // Sort matches inside each league
    for (const g of groups) {
      g.matches.sort((a, b) => {
        if (sortMode === 'live-first') {
          const scoreA = a.status === 'live' ? 0 : a.status === 'scheduled' ? 1 : 2;
          const scoreB = b.status === 'live' ? 0 : b.status === 'scheduled' ? 1 : 2;
          if (scoreA !== scoreB) return scoreA - scoreB;
        }
        return (a.dayTime || '').localeCompare(b.dayTime || '');
      });
    }

    // Sort leagues according to user preference
    groups.sort((a, b) => {
      const aFav = favLeagueSet.has(a.leagueKey) ? 0 : 1;
      const bFav = favLeagueSet.has(b.leagueKey) ? 0 : 1;
      if (aFav !== bFav) return aFav - bFav;

      if (sortMode === 'live-first') {
        if (a.liveInGroup > 0 && b.liveInGroup === 0) return -1;
        if (b.liveInGroup > 0 && a.liveInGroup === 0) return 1;
        if (a.liveInGroup !== b.liveInGroup) return b.liveInGroup - a.liveInGroup;
      } else if (sortMode === 'time') {
        const aTime = a.matches[0]?.dayTime || '99:99';
        const bTime = b.matches[0]?.dayTime || '99:99';
        if (aTime !== bTime) return aTime.localeCompare(bTime);
      }

      if (a.meta.rank !== b.meta.rank) return a.meta.rank - b.meta.rank;
      return a.meta.leagueKey.localeCompare(b.meta.leagueKey);
    });

    return groups;
  }, [filteredMatches, leagueMetaMap, favLeagueSet, sortMode]);

  // Ordered league options for dropdown selector
  const orderedDropdownLeagues = useMemo(() => {
    return [...leagues].sort((a, b) => {
      const aFav = favLeagueSet.has(a.leagueKey) ? 0 : 1;
      const bFav = favLeagueSet.has(b.leagueKey) ? 0 : 1;
      if (aFav !== bFav) return aFav - bFav;
      if (a.rank !== b.rank) return a.rank - b.rank;
      return a.leagueKey.localeCompare(b.leagueKey);
    });
  }, [leagues, favLeagueSet]);

  const enrichMinuteForDisplay = (m: SiteLiveMatch): SiteLiveMatch => {
    if (m.status !== 'live' || minuteStepsSincePoll === 0) return m;
    return {
      ...m,
      liveMinute: advanceMinuteTick(m.liveMinute, minuteStepsSincePoll),
    };
  };

  const formattedScanClock = useMemo(() => {
    if (!scannedAt) return '--:--:--';
    const d = new Date(scannedAt);
    if (Number.isNaN(d.getTime())) return '--:--:--';
    return d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  }, [scannedAt]);

  return (
    <div className="space-y-3" dir="rtl">
      {/* 1. LIVE DOMAIN SCANNER HEADER & PERMANENT LIVE CONTROLS */}
      <div className="rounded-3xl bg-gradient-to-br from-[#07152f] via-[#0b224a] to-[#061126] border-2 border-sky-400/75 p-3 sm:p-4 shadow-[0_0_28px_rgba(56,189,248,0.28)] space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-emerald-400 to-cyan-500 text-black flex items-center justify-center shadow-[0_0_16px_rgba(16,185,129,0.75)] border border-white/80 shrink-0">
              <Radar className={`w-5 h-5 ${isScanning || alwaysLiveActive ? 'animate-spin' : ''}`} style={{ animationDuration: alwaysLiveActive && !isScanning ? '5s' : undefined }} />
            </div>
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-1.5">
                <h2 className="text-sm sm:text-base font-black text-white">
                  المباشر — مسح النطاق الحي
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-400 text-emerald-200 font-black text-[10px] tabular-nums whitespace-nowrap">
                  {liveMatchesCount} مباشر الآن
                </span>
              </div>
              <p className="text-[10px] sm:text-[11px] text-cyan-200/90 font-mono truncate" dir="ltr">
                promosport-pronostic.com/welcome/promosport • {formattedScanClock}
              </p>
            </div>
          </div>

          {/* Scan Now + Permanent Always-Live Toggle */}
          <div className="flex flex-wrap items-center gap-1.5">
            <button
              type="button"
              onClick={toggleAlwaysLive}
              className={`min-h-[38px] px-3 py-1.5 rounded-xl border font-black text-[11px] flex items-center gap-1.5 transition-all cursor-pointer active:scale-95 whitespace-nowrap ${
                alwaysLiveActive
                  ? 'bg-emerald-500 text-black border-white shadow-[0_0_14px_rgba(16,185,129,0.85)]'
                  : 'bg-black/60 text-gray-300 border-white/25 hover:border-emerald-400/70'
              }`}
            >
              <Radio className={`w-3.5 h-3.5 ${alwaysLiveActive ? 'animate-pulse' : ''}`} />
              <span>{alwaysLiveActive ? 'المباشر دوماً: مفعل' : 'المباشر دوماً: متوقف'}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                audioService.playClick();
                void performScan(true, false);
              }}
              disabled={isScanning}
              className="min-h-[38px] px-3 py-1.5 rounded-xl bg-gradient-to-r from-yellow-300 via-amber-400 to-yellow-500 hover:brightness-105 text-black border border-yellow-100 font-black text-[11px] flex items-center gap-1.5 shadow-[0_0_14px_rgba(250,204,21,0.65)] transition-all cursor-pointer active:scale-95 disabled:opacity-70 whitespace-nowrap"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} />
              <span>{isScanning ? 'جارٍ المسح...' : 'مسح نطاق Scan'}</span>
            </button>
          </div>
        </div>

        {/* 4 Filter Mode Tabs: الكل / المباشر الآن / المشاهدة المباشرة / التفضيلات */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
          <button
            type="button"
            onClick={() => {
              audioService.playClick();
              setFilterTab('all');
            }}
            className={`min-h-[40px] px-2.5 py-1.5 rounded-xl border text-[11px] font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
              filterTab === 'all'
                ? 'bg-sky-500 text-black border-white shadow-[0_0_14px_rgba(56,189,248,0.75)]'
                : 'bg-black/50 text-sky-100 border-sky-400/40 hover:border-sky-300'
            }`}
          >
            <Globe2 className="w-3.5 h-3.5 shrink-0" />
            <span className="tabular-nums">كل المباريات ({matches.length})</span>
          </button>

          <button
            type="button"
            onClick={() => {
              audioService.playClick();
              setFilterTab('live');
            }}
            className={`min-h-[40px] px-2.5 py-1.5 rounded-xl border text-[11px] font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
              filterTab === 'live'
                ? 'bg-emerald-500 text-black border-white shadow-[0_0_14px_rgba(16,185,129,0.75)]'
                : 'bg-black/50 text-emerald-200 border-emerald-400/40 hover:border-emerald-300'
            }`}
          >
            <Radio className="w-3.5 h-3.5 shrink-0" />
            <span className="tabular-nums">المباشر الآن ({liveMatchesCount})</span>
          </button>

          <button
            type="button"
            onClick={() => {
              audioService.playClick();
              setFilterTab('watch');
            }}
            className={`min-h-[40px] px-2.5 py-1.5 rounded-xl border text-[11px] font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
              filterTab === 'watch'
                ? 'bg-cyan-400 text-black border-white shadow-[0_0_14px_rgba(34,211,238,0.75)]'
                : 'bg-black/50 text-cyan-200 border-cyan-400/40 hover:border-cyan-300'
            }`}
          >
            <Tv className="w-3.5 h-3.5 shrink-0" />
            <span className="tabular-nums">المشاهدة ({watchMatchIds.length})</span>
          </button>

          <button
            type="button"
            onClick={() => {
              audioService.playClick();
              setFilterTab('favorites');
            }}
            className={`min-h-[40px] px-2.5 py-1.5 rounded-xl border text-[11px] font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
              filterTab === 'favorites'
                ? 'bg-gradient-to-r from-yellow-300 to-amber-500 text-black border-white shadow-[0_0_14px_rgba(250,204,21,0.85)]'
                : 'bg-black/50 text-yellow-200 border-yellow-400/40 hover:border-yellow-300'
            }`}
          >
            <Star className={`w-3.5 h-3.5 shrink-0 ${filterTab === 'favorites' ? 'fill-black' : ''}`} />
            <span className="tabular-nums">
              التفضيلات ({favoriteMatchIds.length + favoriteLeagues.length})
            </span>
          </button>
        </div>

        {/* Search, League Filter & League Ordering Selector (ترتيب الدوريات) */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          {/* Team / League Search */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-sky-300 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث عن فريق أو بطولة..."
              className="w-full min-h-[38px] pr-8 pl-3 py-1.5 rounded-xl bg-black/70 border border-sky-400/45 focus:border-yellow-400 text-xs text-white placeholder-gray-400 outline-none"
            />
          </div>

          {/* League Filter */}
          <div className="relative">
            <Filter className="w-3.5 h-3.5 text-yellow-300 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <select
              value={selectedLeagueKey}
              onChange={(e) => {
                audioService.playClick();
                setSelectedLeagueKey(e.target.value);
              }}
              className="w-full min-h-[38px] pr-8 pl-3 py-1.5 rounded-xl bg-black/70 border border-sky-400/45 focus:border-yellow-400 text-xs font-bold text-white outline-none cursor-pointer"
            >
              <option value="ALL">كل الدوريات ({leagues.length})</option>
              {orderedDropdownLeagues.map((l) => (
                <option key={l.leagueKey} value={l.leagueKey}>
                  {favLeagueSet.has(l.leagueKey) ? '★ ' : ''}
                  {l.countryAr} : {l.leagueName} ({l.liveCount > 0 ? `${l.liveCount} مباشر / ` : ''}
                  {l.totalCount})
                </option>
              ))}
            </select>
          </div>

          {/* Sort Mode (`ترتيب الدوريات`) */}
          <div className="relative">
            <ArrowUpDown className="w-3.5 h-3.5 text-emerald-300 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <select
              value={sortMode}
              onChange={(e) => {
                audioService.playClick();
                setSortMode(e.target.value as LeagueSortMode);
              }}
              className="w-full min-h-[38px] pr-8 pl-3 py-1.5 rounded-xl bg-black/70 border border-sky-400/45 focus:border-yellow-400 text-xs font-bold text-emerald-200 outline-none cursor-pointer"
            >
              <option value="league-priority">ترتيب الدوريات (المفضلة ثم الأهمية)</option>
              <option value="live-first">ترتيب الدوريات (المباشر أولاً)</option>
              <option value="time">ترتيب الدوريات (حسب التوقيت)</option>
            </select>
          </div>
        </div>
      </div>

      {/* 2. PINNED LIVE WATCH LIST (المباريات المختارة للمشاهدة المباشرة لحظة بلحظة) */}
      {filterTab !== 'watch' && pinnedWatchedMatches.length > 0 && (
        <div className="space-y-3 rounded-3xl bg-gradient-to-b from-emerald-950/60 via-[#071832]/85 to-[#050e20]/90 border-2 border-emerald-400/75 p-2.5 sm:p-3.5 shadow-[0_0_24px_rgba(16,185,129,0.28)]">
          <div className="flex items-center justify-between px-1">
            <div className="flex items-center gap-2">
              <span className="w-7 h-7 rounded-xl bg-emerald-500 text-black flex items-center justify-center shadow">
                <Tv className="w-4 h-4" />
              </span>
              <div>
                <h3 className="text-xs sm:text-sm font-black text-emerald-200">
                  المشاهدة المباشرة المختارة ({pinnedWatchedMatches.length})
                </h3>
                <p className="text-[10px] text-emerald-100/80">
                  تحديث فوري لحظة بلحظة للنتائج والدقائق المختارة
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {pinnedWatchedMatches.map((rawMatch) => {
              const m = enrichMinuteForDisplay(rawMatch);
              return (
                <PinterestScoreboardCard
                  key={`pinned-${m.siteMatchId}`}
                  match={m}
                  lang={lang}
                  mode="live"
                  getTeamName={getTeamName}
                  justScoredGoal={Boolean(goalFlashMap[m.siteMatchId])}
                  isFavorite={favMatchSet.has(m.siteMatchId)}
                  onToggleFavorite={() => toggleFavoriteMatch(m.siteMatchId)}
                  isWatchingLive={true}
                  onToggleWatchLive={() => toggleWatchLiveMatch(m.siteMatchId)}
                />
              );
            })}
          </div>
        </div>
      )}

      {/* 3. ERROR / INITIAL SCANNING / EMPTY STATES */}
      {scanError && matches.length === 0 ? (
        <div className="rounded-2xl bg-red-950/60 border border-red-400/70 p-5 text-center space-y-3">
          <p className="text-xs sm:text-sm font-bold text-red-200">{scanError}</p>
          <button
            type="button"
            onClick={() => void performScan(true, false)}
            className="min-h-[40px] px-4 py-2 rounded-xl bg-yellow-400 text-black font-black text-xs inline-flex items-center gap-2 cursor-pointer"
          >
            <RefreshCw className="w-4 h-4" />
            <span>إعادة المسح الآن</span>
          </button>
        </div>
      ) : isScanning && matches.length === 0 ? (
        <div className="rounded-3xl bg-[#07152d]/90 border border-sky-400/50 p-8 text-center space-y-3">
          <RefreshCw className="w-8 h-8 text-cyan-300 animate-spin mx-auto" />
          <p className="text-sm font-black text-cyan-100">
            جارٍ مسح النطاق المباشر واستخراج جميع الدوريات والمقابلات الصحيحة...
          </p>
          <p className="text-[11px] text-sky-300 font-mono" dir="ltr">
            https://www.promosport-pronostic.com/welcome/promosport
          </p>
        </div>
      ) : orderedLeagueGroups.length === 0 ? (
        <div className="rounded-3xl bg-[#07152d]/85 border border-sky-400/40 p-6 text-center space-y-2.5">
          <Trophy className="w-8 h-8 text-yellow-300 mx-auto opacity-80" />
          <p className="text-sm font-black text-gray-200">
            لا توجد مقابلات مطابقة للتصفية الحالية
          </p>
          <button
            type="button"
            onClick={() => {
              audioService.playClick();
              setFilterTab('all');
              setSelectedLeagueKey('ALL');
              setSearchQuery('');
            }}
            className="min-h-[38px] px-4 py-1.5 rounded-xl bg-sky-500 text-black font-black text-xs cursor-pointer"
          >
            إظهار جميع المباريات
          </button>
        </div>
      ) : (
        /* 4. GROUPED ORDERED LEAGUES WITH EXACT GRILLE-STYLE MATCH CARDS */
        <div className="space-y-5">
          {orderedLeagueGroups.map((group) => {
            const { meta, matches: groupMatches, liveInGroup } = group;
            const isLeagueFav = favLeagueSet.has(meta.leagueKey);
            const flagImgKey = `flag:${meta.leagueKey}`;
            const logoImgKey = `logo:${meta.leagueKey}`;

            return (
              <section key={meta.leagueKey} className="space-y-3">
                {/* League Header Banner */}
                <div
                  className={`rounded-2xl px-3 py-2 border flex items-center justify-between gap-2 shadow-md ${
                    isLeagueFav
                      ? 'bg-gradient-to-r from-amber-950/85 via-[#18294e] to-amber-950/85 border-yellow-400/85 shadow-[0_0_16px_rgba(250,204,21,0.28)]'
                      : liveInGroup > 0
                      ? 'bg-gradient-to-r from-emerald-950/80 via-[#0a2346] to-[#081936] border-emerald-400/70'
                      : 'bg-gradient-to-r from-[#081732] via-[#0c234b] to-[#081732] border-sky-400/50'
                  }`}
                >
                  <div className="flex items-center gap-2 min-w-0">
                    {meta.countryFlagUrl && !failedImages[flagImgKey] ? (
                      <img
                        src={meta.countryFlagUrl}
                        alt={meta.countryName}
                        referrerPolicy="no-referrer"
                        loading="lazy"
                        onError={() => setFailedImages((p) => ({ ...p, [flagImgKey]: true }))}
                        className="w-6 h-4 object-cover rounded-sm border border-white/60 shrink-0"
                      />
                    ) : (
                      <Globe2 className="w-4 h-4 text-sky-300 shrink-0" />
                    )}

                    {meta.leagueLogoUrl && !failedImages[logoImgKey] && (
                      <img
                        src={meta.leagueLogoUrl}
                        alt={meta.leagueName}
                        referrerPolicy="no-referrer"
                        loading="lazy"
                        onError={() => setFailedImages((p) => ({ ...p, [logoImgKey]: true }))}
                        className="w-5 h-5 object-contain rounded-full bg-white/95 p-0.5 shrink-0"
                      />
                    )}

                    <div className="min-w-0">
                      <div className="text-xs sm:text-sm font-black text-white truncate">
                        {meta.countryAr} — <span className="text-yellow-200">{meta.leagueName}</span>
                      </div>
                      <div className="text-[10px] text-sky-200/85 font-bold flex items-center gap-2 tabular-nums">
                        <span>{groupMatches.length} مقابلة</span>
                        {liveInGroup > 0 && (
                          <span className="text-emerald-300 font-black">• {liveInGroup} مباشر الآن</span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Favorite League Toggle */}
                  <button
                    type="button"
                    onClick={() => toggleFavoriteLeague(meta.leagueKey)}
                    title={isLeagueFav ? 'إزالة الدوري من التفضيلات' : 'تفضيل الدوري وتثبيته في الأعلى'}
                    className={`min-h-[36px] px-2.5 py-1 rounded-xl border font-black text-[10.5px] flex items-center gap-1 transition-all cursor-pointer active:scale-95 shrink-0 whitespace-nowrap ${
                      isLeagueFav
                        ? 'bg-gradient-to-b from-yellow-300 to-amber-500 text-black border-white shadow-[0_0_12px_rgba(250,204,21,0.85)]'
                        : 'bg-black/55 hover:bg-amber-950/75 text-yellow-200 border-yellow-300/60'
                    }`}
                  >
                    <Star className={`w-3.5 h-3.5 shrink-0 ${isLeagueFav ? 'fill-black text-black' : ''}`} />
                    <span>{isLeagueFav ? 'دوري مفضل' : 'تفضيل الدوري'}</span>
                  </button>
                </div>

                {/* Match Cards Using Exact Grille Card Geometry & Colors (Scaled 50%) */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {groupMatches.map((rawMatch) => {
                    const m = enrichMinuteForDisplay(rawMatch);
                    return (
                      <PinterestScoreboardCard
                        key={m.siteMatchId}
                        match={m}
                        lang={lang}
                        mode="live"
                        getTeamName={getTeamName}
                        justScoredGoal={Boolean(goalFlashMap[m.siteMatchId])}
                        isFavorite={favMatchSet.has(m.siteMatchId)}
                        onToggleFavorite={() => toggleFavoriteMatch(m.siteMatchId)}
                        isWatchingLive={watchSet.has(m.siteMatchId)}
                        onToggleWatchLive={() => toggleWatchLiveMatch(m.siteMatchId)}
                      />
                    );
                  })}
                </div>
              </section>
            );
          })}
        </div>
      )}
    </div>
  );
};
