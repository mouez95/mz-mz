/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useMemo, useState } from 'react';
import { Lock, RefreshCw } from 'lucide-react';
import { PromosportGrille } from '../types/promosport';

interface TirageFrozenSnapshotCardProps {
  grille: PromosportGrille;
  lang: 'AR' | 'FR';
  getTeamName?: (teamName: string, frName?: string) => string;
  isRefreshingPayouts?: boolean;
  onRefreshPayoutsOnly?: () => void;
}

function drawRoundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  const radius = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + w - radius, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
  ctx.lineTo(x + w, y + h - radius);
  ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h);
  ctx.lineTo(x + radius, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
}

function truncateCanvasText(ctx: CanvasRenderingContext2D, text: string, maxWidth: number): string {
  if (ctx.measureText(text).width <= maxWidth) return text;
  let clipped = text;
  while (clipped.length > 1 && ctx.measureText(`${clipped}…`).width > maxWidth) {
    clipped = clipped.slice(0, -1);
  }
  return `${clipped}…`;
}

export const TirageFrozenSnapshotCard: React.FC<TirageFrozenSnapshotCardProps> = ({
  grille,
  lang,
  getTeamName,
  isRefreshingPayouts = false,
  onRefreshPayoutsOnly,
}) => {
  const [snapshotDataUrl, setSnapshotDataUrl] = useState<string | null>(null);
  const [fontsTick, setFontsTick] = useState<number>(0);

  const isOfficial =
    grille.status === 'official' &&
    grille.winnersFormatted !== 'قيد التحديد الرسمي';

  const resolvedMatches = useMemo(
    () =>
      grille.matches.slice(0, 13).map((m) => {
        const home = getTeamName
          ? getTeamName(m.homeTeam, m.homeTeamFr)
          : lang === 'AR'
          ? m.homeTeam
          : m.homeTeamFr || m.homeTeam;
        const away = getTeamName
          ? getTeamName(m.awayTeam, m.awayTeamFr)
          : lang === 'AR'
          ? m.awayTeam
          : m.awayTeamFr || m.awayTeam;
        const scoreMatch = String(m.score || '').match(/^(\d+)\s*[-:]\s*(\d+)$/);
        const finalScore = scoreMatch ? `${scoreMatch[1]} - ${scoreMatch[2]}` : '- - -';
        const finalSign: '1' | 'X' | '2' | '-' =
          scoreMatch && m.result ? m.result : scoreMatch ? m.result || '-' : '-';
        return {
          id: m.id,
          home,
          away,
          finalScore,
          finalSign,
          comp:
            lang === 'AR'
              ? m.competition || `#${grille.number}`
              : m.competitionFr || m.competition || `#${grille.number}`,
        };
      }),
    [grille.matches, grille.number, lang, getTeamName]
  );

  // Re-render snapshot once web fonts finish loading if available
  useEffect(() => {
    const fontsApi = (document as unknown as { fonts?: { ready?: Promise<unknown> } }).fonts;
    if (fontsApi && fontsApi.ready && typeof fontsApi.ready.then === 'function') {
      let active = true;
      fontsApi.ready
        .then(() => {
          if (active) setFontsTick((t) => t + 1);
        })
        .catch(() => {});
      return () => {
        active = false;
      };
    }
    return undefined;
  }, []);

  // Render immutable static PNG image snapshot strictly reflecting final results & official payouts
  useEffect(() => {
    try {
      const canvas = document.createElement('canvas');
      const cssWidth = 840;
      const headerHeight = 166;
      const payoutsHeight = 112;
      const rowHeight = 62;
      const rowGap = 10;
      const footerHeight = 52;
      const totalHeight =
        headerHeight +
        payoutsHeight +
        20 +
        resolvedMatches.length * (rowHeight + rowGap) +
        footerHeight;

      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.round(cssWidth * dpr);
      canvas.height = Math.round(totalHeight * dpr);

      const ctx = canvas.getContext('2d');
      if (!ctx) {
        setSnapshotDataUrl(null);
        return;
      }

      ctx.scale(dpr, dpr);

      // 1. Deep navy ticket canvas backdrop
      const bgGrad = ctx.createLinearGradient(0, 0, 0, totalHeight);
      bgGrad.addColorStop(0, '#040b1a');
      bgGrad.addColorStop(0.5, '#071530');
      bgGrad.addColorStop(1, '#030914');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, cssWidth, totalHeight);

      // Outer gold frame border
      drawRoundedRect(ctx, 8, 8, cssWidth - 16, totalHeight - 16, 20);
      ctx.strokeStyle = isOfficial ? '#facc15' : '#f59e0b';
      ctx.lineWidth = 3;
      ctx.stroke();

      // 2. Top Banner Header
      drawRoundedRect(ctx, 22, 22, cssWidth - 44, 128, 16);
      const hdrGrad = ctx.createLinearGradient(22, 22, cssWidth - 22, 150);
      hdrGrad.addColorStop(0, '#0a1f47');
      hdrGrad.addColorStop(0.5, '#0f2d63');
      hdrGrad.addColorStop(1, '#0a1f47');
      ctx.fillStyle = hdrGrad;
      ctx.fill();
      ctx.strokeStyle = 'rgba(250, 204, 21, 0.55)';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Draw Number Badge
      drawRoundedRect(ctx, 38, 42, 86, 86, 16);
      const badgeGrad = ctx.createLinearGradient(38, 42, 124, 128);
      badgeGrad.addColorStop(0, '#fde047');
      badgeGrad.addColorStop(1, '#f59e0b');
      ctx.fillStyle = badgeGrad;
      ctx.fill();

      ctx.fillStyle = '#000000';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.font = '900 28px Cairo, Arial, sans-serif';
      ctx.fillText(`#${grille.number}`, 81, 86);

      // Header Titles
      ctx.textAlign = 'left';
      ctx.fillStyle = '#fde047';
      ctx.font = '900 24px Cairo, Arial, sans-serif';
      const titleText =
        lang === 'AR'
          ? `القصاصة السابقة الأخيرة · N° ${grille.number}`
          : `Dernier Tirage · Concours N° ${grille.number}`;
      ctx.fillText(titleText, 142, 64);

      ctx.fillStyle = '#cbd5e1';
      ctx.font = '700 16px Cairo, Arial, sans-serif';
      ctx.fillText(grille.date, 142, 96);

      // Static Snapshot Seal Text
      ctx.fillStyle = isOfficial ? '#34d399' : '#fbbf24';
      ctx.font = '800 15px Cairo, Arial, sans-serif';
      const sealText = isOfficial
        ? lang === 'AR'
          ? 'صورة نهائية مجمدة · النتائج والمرابيح معتمدة'
          : 'Image figée officielle · Résultats et gains publiés'
        : lang === 'AR'
        ? 'صورة جامدة · تحديث القيمة المالية والمرابيح فقط عند النشر'
        : 'Image figée · Mise à jour des gains uniquement';
      ctx.fillText(sealText, 142, 124);

      // 3. Payouts & Cagnotte Strip
      const py = headerHeight;
      drawRoundedRect(ctx, 22, py, cssWidth - 44, payoutsHeight - 10, 14);
      ctx.fillStyle = '#030916';
      ctx.fill();
      ctx.strokeStyle = 'rgba(250, 204, 21, 0.4)';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      const colW = (cssWidth - 44) / 3;
      const cols = [
        {
          label: lang === 'AR' ? 'القيمة المالية' : 'Cagnotte',
          val: grille.cagnotteFormatted,
          color: '#34d399',
        },
        {
          label: lang === 'AR' ? 'عدد المرابيح' : 'Gagnants',
          val: grille.winnersFormatted,
          color: '#ffffff',
        },
        {
          label: lang === 'AR' ? 'نصيب كل فائز' : 'Part / Colonne',
          val: grille.prizePerWinnerFormatted,
          color: '#fde047',
        },
      ];

      cols.forEach((c, idx) => {
        const cx = 22 + colW * idx + colW / 2;
        if (idx > 0) {
          ctx.beginPath();
          ctx.moveTo(22 + colW * idx, py + 14);
          ctx.lineTo(22 + colW * idx, py + payoutsHeight - 24);
          ctx.strokeStyle = 'rgba(255,255,255,0.12)';
          ctx.lineWidth = 1;
          ctx.stroke();
        }
        ctx.textAlign = 'center';
        ctx.fillStyle = '#94a3b8';
        ctx.font = '700 14px Cairo, Arial, sans-serif';
        ctx.fillText(c.label, cx, py + 28);

        ctx.fillStyle = c.color;
        ctx.font = '900 19px Cairo, Arial, sans-serif';
        ctx.fillText(truncateCanvasText(ctx, c.val, colW - 18), cx, py + 64);
      });

      // 4. Settled 13 Match Rows (Frozen Final Snapshot — Zero Live Status)
      let curY = headerHeight + payoutsHeight + 8;

      resolvedMatches.forEach((m) => {
        // Winged Blue Chassis
        drawRoundedRect(ctx, 22, curY, cssWidth - 44, rowHeight, 14);
        const rowGrad = ctx.createLinearGradient(22, curY, 22, curY + rowHeight);
        rowGrad.addColorStop(0, '#1366dc');
        rowGrad.addColorStop(0.5, '#0745ab');
        rowGrad.addColorStop(1, '#02266b');
        ctx.fillStyle = rowGrad;
        ctx.fill();
        ctx.strokeStyle = '#cbd5e1';
        ctx.lineWidth = 2;
        ctx.stroke();

        // Match index box
        drawRoundedRect(ctx, 32, curY + 13, 36, 36, 9);
        ctx.fillStyle = '#09152c';
        ctx.fill();
        ctx.strokeStyle = '#fde047';
        ctx.lineWidth = 1.5;
        ctx.stroke();

        ctx.textAlign = 'center';
        ctx.fillStyle = '#fde047';
        ctx.font = '900 15px Cairo, Arial, sans-serif';
        ctx.fillText(String(m.id), 50, curY + 32);

        // Home Team (Left)
        ctx.textAlign = 'left';
        ctx.fillStyle = '#ffffff';
        ctx.font = '900 17px Cairo, Arial, sans-serif';
        ctx.fillText(truncateCanvasText(ctx, m.home, 235), 80, curY + 32);

        // Center Score Medallion
        drawRoundedRect(ctx, 332, curY + 9, 128, 44, 22);
        ctx.fillStyle = '#0c1118';
        ctx.fill();
        ctx.strokeStyle = '#e2e8f0';
        ctx.lineWidth = 2;
        ctx.stroke();

        ctx.textAlign = 'center';
        ctx.fillStyle = m.finalScore !== '- - -' ? '#fde047' : '#cbd5e1';
        ctx.font = '900 20px monospace';
        ctx.fillText(m.finalScore, 396, curY + 32);

        // Away Team (Right of Score)
        ctx.textAlign = 'right';
        ctx.fillStyle = '#ffffff';
        ctx.font = '900 17px Cairo, Arial, sans-serif';
        ctx.fillText(truncateCanvasText(ctx, m.away, 235), cssWidth - 96, curY + 32);

        // Outcome 1/X/2 Stamp Box (Far Right)
        drawRoundedRect(ctx, cssWidth - 82, curY + 11, 48, 40, 10);
        ctx.fillStyle =
          m.finalSign === '1'
            ? '#ef4444'
            : m.finalSign === 'X'
            ? '#facc15'
            : m.finalSign === '2'
            ? '#2563eb'
            : '#1e293b';
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1.5;
        ctx.stroke();

        ctx.textAlign = 'center';
        ctx.fillStyle = m.finalSign === 'X' ? '#000000' : '#ffffff';
        ctx.font = '900 18px Cairo, Arial, sans-serif';
        ctx.fillText(m.finalSign, cssWidth - 58, curY + 32);

        curY += rowHeight + rowGap;
      });

      // 5. Footer Watermark inside Snapshot Image
      ctx.textAlign = 'center';
      ctx.fillStyle = '#94a3b8';
      ctx.font = '700 13px Cairo, Arial, sans-serif';
      ctx.fillText(
        `Tirage N° ${grille.number} · صورة ثابتة غير تفاعلية · promosport-pronostic.com`,
        cssWidth / 2,
        totalHeight - 24
      );

      setSnapshotDataUrl(canvas.toDataURL('image/png'));
    } catch {
      setSnapshotDataUrl(null);
    }
  }, [
    grille.number,
    grille.date,
    grille.cagnotteFormatted,
    grille.winnersFormatted,
    grille.prizePerWinnerFormatted,
    isOfficial,
    lang,
    resolvedMatches,
    fontsTick,
  ]);

  return (
    <div className="space-y-3 select-none">
      {/* Status Banner & Payout-Only Check Action (Hidden once official payouts freeze permanently) */}
      <div className="rounded-2xl bg-[#08152e]/95 border border-yellow-400/60 px-3.5 py-2.5 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <Lock className="w-4 h-4 text-yellow-400 shrink-0" />
          <span className="text-xs font-bold text-gray-200 leading-relaxed">
            {isOfficial
              ? lang === 'AR'
                ? 'تم إعلان القيمة المالية ونصيب كل فائز — القصاصة مجمدة كصورة نهائية فقط'
                : 'Cagnotte et gains publiés — Grille figée en image finale'
              : lang === 'AR'
              ? 'القصاصة السابقة صورة جامدة دون بث مباشر — يتم تحديث القيمة المالية ونصيب كل فائز فقط عند ظهورها'
              : 'Image figée sans direct — Mise à jour des gains uniquement'}
          </span>
        </div>

        {!isOfficial && onRefreshPayoutsOnly && (
          <button
            type="button"
            onClick={onRefreshPayoutsOnly}
            disabled={isRefreshingPayouts}
            className="min-h-[40px] px-3 py-1.5 rounded-xl bg-yellow-400/15 hover:bg-yellow-400/25 border border-yellow-400/50 text-yellow-300 font-bold text-xs flex items-center gap-1.5 cursor-pointer disabled:opacity-60 shrink-0"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshingPayouts ? 'animate-spin' : ''}`} />
            <span>تحديث القيمة المالية والمرابيح</span>
          </button>
        )}
      </div>

      {/* True Frozen Static Image (صورة جامدة فقط) */}
      {snapshotDataUrl ? (
        <div className="w-full overflow-hidden rounded-2xl shadow-[0_12px_36px_rgba(0,0,0,0.85)]">
          <img
            src={snapshotDataUrl}
            alt={`صورة مجمدة للقصاصة السابقة رقم ${grille.number}`}
            draggable={false}
            className="w-full h-auto block pointer-events-none select-none"
          />
        </div>
      ) : (
        /* Static Non-Interactive DOM Fallback Mirror while Image Encodes */
        <div className="w-full rounded-2xl bg-[#040b1a] border-2 border-yellow-400/70 p-3 space-y-3 pointer-events-none select-none">
          <div className="flex items-center justify-between border-b border-white/10 pb-2">
            <div>
              <div className="text-sm font-black text-yellow-300">
                القصاصة السابقة الأخيرة · N° {grille.number}
              </div>
              <div className="text-xs text-gray-300 font-mono" dir="ltr">
                {grille.date}
              </div>
            </div>
            <div className="text-right">
              <div className="text-[11px] text-gray-400">القيمة المالية</div>
              <div className="text-sm font-black text-emerald-300 font-mono tabular-nums" dir="ltr">
                {grille.cagnotteFormatted}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 text-center bg-black/45 p-2 rounded-xl border border-yellow-400/30 text-xs">
            <div>
              <span className="block text-[10px] text-gray-400">القيمة المالية</span>
              <span className="font-black text-emerald-300 font-mono tabular-nums" dir="ltr">
                {grille.cagnotteFormatted}
              </span>
            </div>
            <div>
              <span className="block text-[10px] text-gray-400">عدد المرابيح</span>
              <span className="font-black text-white tabular-nums">{grille.winnersFormatted}</span>
            </div>
            <div>
              <span className="block text-[10px] text-gray-400">نصيب كل فائز</span>
              <span className="font-black text-yellow-300 font-mono tabular-nums" dir="ltr">
                {grille.prizePerWinnerFormatted}
              </span>
            </div>
          </div>

          <div className="space-y-1.5" dir="ltr">
            {resolvedMatches.map((m) => (
              <div
                key={m.id}
                className="flex items-center justify-between gap-2 px-2.5 py-2 rounded-xl bg-[#07368e] border border-slate-300/60 text-xs text-white"
              >
                <span className="font-mono font-black text-yellow-300 w-5">{m.id}</span>
                <span className="flex-1 truncate font-bold text-left">{m.home}</span>
                <span className="px-2 py-0.5 rounded-lg bg-black/80 text-yellow-300 font-mono font-black">
                  {m.finalScore}
                </span>
                <span className="flex-1 truncate font-bold text-right">{m.away}</span>
                <span className="w-6 h-6 rounded-md bg-black/60 border border-white/40 flex items-center justify-center font-black">
                  {m.finalSign}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
