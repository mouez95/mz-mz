/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  ArrowRight,
  Trash2,
  Edit3,
  Save,
  Trophy,
  Check,
  ChevronDown,
  ChevronUp,
  Receipt,
  Calendar,
  LayoutGrid,
} from 'lucide-react';
import { UserBetSlip, WeeklyConcours } from '../types/promosport';
import { MbLogo } from './MbLogo';
import { PinterestScoreboardCard } from './PinterestScoreboardCard';
import { audioService } from '../services/audioService';
import { calculatePromosportPrice } from '../services/pricingService';
import confetti from 'canvas-confetti';

interface SavedSlipFullPageViewProps {
  slip: UserBetSlip;
  concours: WeeklyConcours;
  lang: 'AR' | 'FR';
  onBackToSlips: () => void;
  onBackToGrille: () => void;
  onUpdateSlip: (updatedSlip: UserBetSlip) => void;
  onDeleteSlip: (slipId: string) => void;
  getTeamName: (teamName: string, frName?: string) => string;
  isKickoffStarted?: boolean;
  columnRate?: number;
  baseFee?: number;
  goalFlashMatchIds?: Record<number, number>;
}

export const SavedSlipFullPageView: React.FC<SavedSlipFullPageViewProps> = ({
  slip,
  concours,
  lang,
  onBackToSlips,
  onBackToGrille,
  onUpdateSlip,
  onDeleteSlip,
  getTeamName,
  isKickoffStarted = false,
  columnRate = 0.150,
  baseFee = 0.250,
  goalFlashMatchIds = {},
}) => {
  // Toggle for Grand Prize Widget (إظهار وإخفاء الجائزة الكبرى عند النقر على الأيقونة)
  const [isGrandPrizeOpen, setIsGrandPrizeOpen] = useState<boolean>(true);

  // Editing mode state (allows modifying choices directly on this full page)
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [editedSelections, setEditedSelections] = useState<Record<number, ('1' | 'X' | '2')[]>>(() => ({
    ...slip.selections,
  }));
  const [saveSuccessNotice, setSaveSuccessNotice] = useState<boolean>(false);

  // Toggle selection when editing
  const handleToggleSelection = (matchId: number, sign: '1' | 'X' | '2') => {
    if (isKickoffStarted) return;
    audioService.playClick();
    setEditedSelections((prev) => {
      const current = prev[matchId] || [];
      let updated: ('1' | 'X' | '2')[];
      if (current.includes(sign)) {
        updated = current.filter((s) => s !== sign);
        if (updated.length === 0) {
          updated = [sign];
        }
      } else {
        updated = [...current, sign];
      }
      return { ...prev, [matchId]: updated };
    });
  };

  // Calculate stats on edited or saved selections
  const activeSelections = isEditing ? editedSelections : slip.selections;

  let countDoubles = 0;
  let countTriples = 0;
  Object.values(activeSelections).forEach((sel) => {
    if (sel && sel.length > 0) {
      if (sel.length === 2) countDoubles++;
      if (sel.length === 3) countTriples++;
    }
  });

  const pricing = calculatePromosportPrice(countDoubles, countTriples, columnRate, baseFee);

  // Save modified slip
  const handleSaveModifiedSlip = () => {
    if (isKickoffStarted) return;
    audioService.playClick();
    const updatedSlip: UserBetSlip = {
      ...slip,
      selections: editedSelections,
      betType: countTriples > 0 ? 'triple' : countDoubles > 0 ? 'double' : 'single',
      totalCombinations: pricing.combinations,
      totalCostDt: pricing.priceTnd,
      updatedAt: new Date().toLocaleTimeString('ar-TN', { hour: '2-digit', minute: '2-digit' }),
    };

    onUpdateSlip(updatedSlip);
    audioService.playChime();
    confetti({
      particleCount: 40,
      spread: 60,
      colors: ['#f1b816', '#38bdf8', '#10b981'],
    });

    setIsEditing(false);
    setSaveSuccessNotice(true);
    setTimeout(() => setSaveSuccessNotice(false), 2500);
  };

  return (
    <div className="relative flex flex-col h-full bg-[#030918] text-white animate-fade-in overflow-hidden select-none">
      
      {/* 1. TOP HEADER NAVIGATION BAR */}
      <div className="shrink-0 px-2 sm:px-4 pt-[max(0.5rem,env(safe-area-inset-top))] pb-2.5 sm:py-2.5 bg-gradient-to-r from-[#040c1e] via-[#091a38] to-[#040c1e] border-b border-sky-400/50 shadow-lg flex flex-wrap sm:flex-nowrap items-center justify-between gap-1.5 z-20">
        
        {/* SIDE-BY-SIDE NAVIGATION: رجوع إلى القصاصات وبجانبها الرجوع إلى الصفحة الأولى */}
        <div className="flex items-center gap-1.5 shrink-0">
          {/* رجوع إلى القصاصات */}
          <button
            type="button"
            onClick={() => {
              audioService.playClick();
              onBackToSlips();
            }}
            className="flex items-center gap-1 px-2.5 sm:px-3 py-1.5 rounded-xl bg-[#0e2246] hover:bg-[#15346a] border border-sky-400 text-cyan-300 hover:text-white font-bold text-xs transition-all active:scale-95 shadow-md cursor-pointer"
          >
            <ArrowRight className="w-3.5 h-3.5 text-cyan-300" />
            <span className="text-[11px] sm:text-xs">القصاصات</span>
          </button>

          {/* الرجوع إلى القصاصة بجانبها مباشرة */}
          <button
            type="button"
            onClick={() => {
              audioService.playClick();
              onBackToGrille();
            }}
            className="flex items-center gap-1 px-2.5 sm:px-3 py-1.5 rounded-xl bg-gradient-to-r from-sky-600/30 to-blue-700/40 hover:from-sky-500 hover:to-blue-600 border border-sky-400 text-sky-200 hover:text-white font-bold text-xs transition-all active:scale-95 shadow-md cursor-pointer"
          >
            <LayoutGrid className="w-3.5 h-3.5 text-yellow-300" />
            <span className="text-[11px] sm:text-xs">القصاصة</span>
          </button>
        </div>

        {/* Center: Toggle Button for Grand Prize Icon (تفعيل إظهار وإخفاء الجائزة الكبرى) */}
        <button
          type="button"
          aria-expanded={isGrandPrizeOpen}
          onClick={() => {
            audioService.playClick();
            setIsGrandPrizeOpen((prev) => !prev);
          }}
          className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer border shadow-[0_0_12px_rgba(241,184,22,0.4)] active:scale-95 ${
            isGrandPrizeOpen
              ? 'bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 text-black border-white'
              : 'bg-black/85 text-yellow-300 border-yellow-400/80 hover:bg-yellow-950/40'
          }`}
          title="النقر لإظهار أو إخفاء تفاصيل الجائزة الكبرى"
        >
          <Trophy className="w-3.5 h-3.5 text-current shrink-0" />
          <span className="text-[10.5px] sm:text-xs whitespace-nowrap">
            {isGrandPrizeOpen ? 'إخفاء الجائزة' : 'إظهار الجائزة'}
          </span>
          {isGrandPrizeOpen ? <ChevronUp className="w-3.5 h-3.5 shrink-0" /> : <ChevronDown className="w-3.5 h-3.5 shrink-0" />}
        </button>

        {/* Action Controls: Edit / Save (disabled after first kickoff) and Delete (always enabled) */}
        <div className="flex items-center gap-1.5 shrink-0">
          {!isKickoffStarted && (!isEditing ? (
            <button
              type="button"
              onClick={() => {
                audioService.playClick();
                setIsEditing(true);
              }}
              className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-yellow-400 hover:bg-yellow-300 text-black font-black text-xs transition-all flex items-center gap-1 shadow-[0_0_10px_rgba(241,184,22,0.6)] cursor-pointer active:scale-95"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span className="text-[10px] sm:text-xs">تعديل</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={handleSaveModifiedSlip}
              className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 text-black font-black text-xs transition-all flex items-center gap-1 shadow-[0_0_12px_rgba(16,185,129,0.8)] cursor-pointer active:scale-95"
            >
              <Save className="w-3.5 h-3.5" />
              <span className="text-[10px] sm:text-xs">حفظ</span>
            </button>
          ))}

          {/* Delete Slip */}
          <button
            type="button"
            onClick={() => {
              audioService.playClick();
              onDeleteSlip(slip.id);
            }}
            className="px-2.5 py-1.5 rounded-xl bg-red-600/30 hover:bg-red-600 border border-red-500 text-red-200 hover:text-white font-bold text-xs transition-all flex items-center gap-1 active:scale-95 cursor-pointer shadow-md"
            title="فسخ القصاصة"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">فسخ</span>
          </button>
        </div>
      </div>

      {/* Save Success Notice */}
      {saveSuccessNotice && (
        <div className="shrink-0 p-2 bg-emerald-950/95 border-b border-emerald-400 text-emerald-300 text-xs font-bold text-center flex items-center justify-center gap-1.5 animate-fade-in">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>تم حفظ تعديل القصاصة بنجاح!</span>
        </div>
      )}

      {/* 2. FLAT NATURAL VERTICAL SCROLL CONTAINER (بدون 3D وبدون تدوير العجلة) */}
      <div
        className="flex-1 overflow-y-auto overflow-x-hidden overscroll-contain [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]"
        style={{
          WebkitOverflowScrolling: 'touch',
        }}
      >
        {/* GRAND PRIZE HEADER BLOCK SCROLLS UPWARD WITH THE LIST */}
        {isGrandPrizeOpen && (
          <div className="px-3 sm:px-5 py-2.5 bg-gradient-to-r from-[#061533] via-[#0c2452] to-[#061533] border-b-2 border-yellow-400/80 shadow-[0_6px_20px_rgba(241,184,22,0.3)] animate-fade-in">
            <div className="flex flex-wrap items-center justify-between gap-2.5 text-xs">
              
              {/* MB LOGO WITH LASER BEAM + SLIP NUMBER */}
              <div className="flex items-center gap-2.5">
                <MbLogo size="sm" showLaser={true} />
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-lg bg-yellow-400 text-black font-black text-xs sm:text-sm shadow-md">
                      {slip.name}
                    </span>
                    <span className="text-[11px] font-mono text-cyan-300 font-bold">
                      مسابقة #{slip.grilleNumber}
                    </span>
                  </div>
                  <div className="text-[11px] text-gray-300 flex items-center gap-1 mt-0.5 font-medium">
                    <Calendar className="w-3.5 h-3.5 text-yellow-400" />
                    <span>تاريخ ويوم التعمير: {slip.createdAt}</span>
                  </div>
                </div>
              </div>

              {/* GRAND PRIZE CAGNOTTE & SLIP PRICE */}
              <div className="flex flex-wrap items-center gap-2.5 sm:gap-3">
                
                {/* Slip Price (ثمن القصاصة) */}
                <div className="px-3 py-1.5 rounded-xl bg-black/70 border border-emerald-400/60 flex items-center gap-2">
                  <Receipt className="w-4 h-4 text-emerald-400" />
                  <div>
                    <span className="text-[9px] text-gray-400 block font-bold">ثمن القصاصة:</span>
                    <span className="font-mono text-xs sm:text-sm font-black text-emerald-300" dir="ltr">
                      {pricing.priceTnd.toFixed(3)} DT
                    </span>
                  </div>
                </div>

                {/* Grand Prize CAGNOTTE Icon Button (النقر هنا أيضاً يخفي أو يظهر الجائزة الكبرى) */}
                <button
                  type="button"
                  onClick={() => {
                    audioService.playClick();
                    setIsGrandPrizeOpen(false);
                  }}
                  title="النقر لإخفاء بطاقة الجائزة الكبرى"
                  className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500/30 via-yellow-400/30 to-amber-500/30 hover:from-amber-500/45 hover:to-amber-500/45 border border-yellow-400 flex items-center gap-2.5 shadow-[0_0_15px_rgba(241,184,22,0.5)] cursor-pointer active:scale-95 transition-all"
                >
                  <Trophy className="w-5 h-5 text-yellow-400 animate-bounce" />
                  <div className="text-right">
                    <span className="text-[10px] font-black text-yellow-300 block uppercase">الجائزة الكبرى CAGNOTTE</span>
                    <span className="font-mono text-sm sm:text-base font-black text-white tracking-widest drop-shadow-[0_0_8px_#f1b816]" dir="ltr">
                      {concours.cagnotteEstimate}
                    </span>
                  </div>
                </button>

              </div>

            </div>
          </div>
        )}

        <div className="px-1 sm:px-2 pt-3 pb-5 space-y-4">
          {concours.matches.map((match) => {
            const userChoices = activeSelections[match.id] || [];
            const justScoredGoal = Boolean(goalFlashMatchIds[match.id]);

            return (
              <div
                id={`slip-match-${match.id}`}
                key={match.id}
                className="relative w-full"
                dir="ltr"
              >
                <PinterestScoreboardCard
                  match={match}
                  lang={lang}
                  mode="slip"
                  isBettingLocked={isKickoffStarted}
                  slipChoices={userChoices}
                  isEditingSlip={isEditing}
                  onToggleSelection={handleToggleSelection}
                  getTeamName={getTeamName}
                  justScoredGoal={justScoredGoal}
                />
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
