/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Removes white/light background from an image by making light pixels transparent.
 * Caches the result in a DataURL to avoid re-processing.
 */
const processedCache = new Map<string, string>();

export function getTransparentLogoDataUrl(imageSrc: string): Promise<string> {
  if (processedCache.has(imageSrc)) {
    return Promise.resolve(processedCache.get(imageSrc)!);
  }

  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        resolve(imageSrc);
        return;
      }

      ctx.drawImage(img, 0, 0);
      const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const data = imgData.data;

      // Make pixels with high brightness transparent
      for (let i = 0; i < data.length; i += 4) {
        const r = data[i];
        const g = data[i + 1];
        const b = data[i + 2];

        // If pixel is near white (r, g, b > 235)
        if (r > 235 && g > 235 && b > 235) {
          data[i + 3] = 0; // Completely transparent
        } else if (r > 215 && g > 215 && b > 215) {
          // Smooth edge falloff
          const factor = (255 - Math.max(r, g, b)) / 40;
          data[i + 3] = Math.round(data[i + 3] * factor);
        }
      }

      ctx.putImageData(imgData, 0, 0);
      const result = canvas.toDataURL('image/png');
      processedCache.set(imageSrc, result);
      resolve(result);
    };

    img.onerror = () => {
      resolve(imageSrc);
    };

    img.src = imageSrc;
  });
}
