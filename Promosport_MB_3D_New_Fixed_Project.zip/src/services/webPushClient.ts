/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { getSyncApiOrigins } from './promosportData';

export type DesktopPermissionState = NotificationPermission | 'unsupported';

function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

export function getDesktopPermissionState(): DesktopPermissionState {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'unsupported';
  }
  return Notification.permission;
}

async function fetchVapidPublicKey(): Promise<string | null> {
  const origins = getSyncApiOrigins();
  for (const origin of origins) {
    try {
      const res = await fetch(`${origin}/api/push/vapid-public-key`, { cache: 'no-store' });
      if (!res.ok) continue;
      const json = (await res.json()) as { publicKey?: string };
      if (json.publicKey) return json.publicKey;
    } catch {
      // try next origin
    }
  }
  return null;
}

async function sendSubscriptionToServer(subscription: PushSubscription): Promise<boolean> {
  const origins = getSyncApiOrigins();
  const body = JSON.stringify({ subscription: subscription.toJSON() });
  for (const origin of origins) {
    try {
      const res = await fetch(`${origin}/api/push/subscribe`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body,
      });
      if (res.ok) return true;
    } catch {
      // try next origin
    }
  }
  return false;
}

/**
 * Ensures desktop OS notifications & Web Push (works when app is open OR closed)
 * are subscribed cleanly against the Express backend VAPID service.
 */
export async function ensureDesktopPushSubscribed(requestIfNeeded = false): Promise<{
  permission: DesktopPermissionState;
  subscribed: boolean;
}> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return { permission: 'unsupported', subscribed: false };
  }

  let permission: NotificationPermission = Notification.permission;
  if (permission === 'default' && requestIfNeeded) {
    try {
      permission = await Notification.requestPermission();
    } catch {
      permission = Notification.permission;
    }
  }

  if (permission !== 'granted') {
    return { permission, subscribed: false };
  }

  if (!('serviceWorker' in navigator)) {
    return { permission, subscribed: false };
  }

  try {
    const registration = await navigator.serviceWorker.ready;
    // Register periodic background sync if supported (fallback when tab is closed)
    const regSync = registration as ServiceWorkerRegistration & {
      periodicSync?: { register: (tag: string, options: { minInterval: number }) => Promise<void> };
    };
    if (regSync.periodicSync) {
      regSync.periodicSync.register('promosport-grille-sync', { minInterval: 15 * 60 * 1000 }).catch(() => {});
    }

    if (!('pushManager' in registration)) {
      return { permission, subscribed: false };
    }

    let existing = await registration.pushManager.getSubscription();
    if (!existing) {
      const publicKey = await fetchVapidPublicKey();
      if (!publicKey) {
        return { permission, subscribed: false };
      }
      const applicationServerKey = urlBase64ToUint8Array(publicKey);
      existing = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: applicationServerKey.buffer as ArrayBuffer,
      });
    }

    const synced = await sendSubscriptionToServer(existing);
    return { permission, subscribed: synced };
  } catch {
    return { permission, subscribed: false };
  }
}

/**
 * Triggers an immediate desktop OS notification test (local SW + server Web Push verification).
 */
export async function sendTestDesktopNotification(concoursNumber: number): Promise<boolean> {
  const result = await ensureDesktopPushSubscribed(true);
  if (result.permission !== 'granted') {
    return false;
  }

  const title = `إشعارات سطح المكتب مفعّلة — القصاصة ${concoursNumber}`;
  const body = 'ستصلك إشعارات الأهداف والقصاصات الجديدة فوراً سواء كان التطبيق مفتوحاً أو مغلقاً.';

  const origins = getSyncApiOrigins();
  for (const origin of origins) {
    try {
      const res = await fetch(`${origin}/api/push/test`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, body, concoursNumber }),
      });
      if (res.ok) {
        const json = (await res.json()) as { sent?: number };
        if ((json.sent || 0) > 0) {
          return true;
        }
      }
    } catch {
      // continue to local SW fallback
    }
  }

  try {
    if ('serviceWorker' in navigator) {
      const reg = await navigator.serviceWorker.ready;
      if (reg && typeof reg.showNotification === 'function') {
        await reg.showNotification(title, {
          body,
          icon: '/pwa-192x192.png',
          badge: '/pwa-192x192.png',
          dir: 'rtl',
          lang: 'ar',
          tag: `promosport-test-${Date.now()}`,
          data: { url: '/?openGrille=1', concoursNumber },
        });
        return true;
      }
    }
    new Notification(title, {
      body,
      icon: '/pwa-192x192.png',
      dir: 'rtl',
      lang: 'ar',
    });
    return true;
  } catch {
    return false;
  }
}
